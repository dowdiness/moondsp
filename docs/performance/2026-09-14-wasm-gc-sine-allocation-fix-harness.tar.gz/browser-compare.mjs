import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
const {chromium}=await import(process.env.PW_MODULE||'/home/antisatori/ghq/github.com/dowdiness/moondsp/node_modules/playwright/index.mjs');
const root=new URL('./',import.meta.url),results=new URL('browser-results/',root);
await mkdir(results,{recursive:true});
const browser=await chromium.connectOverCDP('http://127.0.0.1:9227',{timeout:15000});
const context=browser.contexts()[0],page=await context.newPage();
await page.goto('http://127.0.0.1:8091/graph-example.html');
const cdp=await context.newCDPSession(page);
const hashes={};for(const variant of ['baseline','fixed'])hashes[variant]=createHash('sha256').update(await readFile(new URL(`web/${variant}.wasm`,root))).digest('hex');
const metadata={baseCommit:'0979c8e8e3cfd0cf40fd4a85aae6cebb3194ba51',date:new Date().toISOString(),browser:await cdp.send('Browser.getVersion'),wasmSha256:hashes,sampleRate:48000,quantum:128,count:16,nodes:3,waveform:'sine',warmupSeconds:2,seconds:5,traceCategories:'webaudio,audio,blink.console,devtools.timeline,v8,disabled-by-default-v8.gc'};
const runs=[];
try{
  for(const round of [0,1,2])for(const variant of (round===1?['fixed','baseline']:['baseline','fixed'])){
    const id=`browser-r${round}-${variant}`;
    const setup=await page.evaluate(async variant=>{
      const {GraphEngine}=await import('/graph-engine.js');
      const c=new AudioContext({sampleRate:48000,latencyHint:'interactive'});await c.suspend();
      const engine=await GraphEngine({context:c,wasmUrl:`/${variant}.wasm`,processorUrl:'/graph-processor.js'});
      window.sineExperiment={c,engine};const sounds=[];
      for(let voice=0;voice<16;voice++)sounds.push(await engine.mount({nodes:[{type:'oscillator',waveform:'sine',frequency:211+voice*37},{type:'gain',input:0,gain:.0005},{type:'output',input:1}]}));
      engine.output.connect(c.destination);for(const sound of sounds)await sound.play();await c.resume();await new Promise(r=>setTimeout(r,2000));
      return {sampleRate:c.sampleRate,state:c.state,baseLatency:c.baseLatency,outputLatency:c.outputLatency};
    },variant);
    await cdp.send('Tracing.start',{categories:metadata.traceCategories,transferMode:'ReturnAsStream'});
    const observation=await page.evaluate(async()=>{
      const {c}=window.sineExperiment;const snap=()=>({state:c.state,currentTime:c.currentTime,stats:c.playbackStats?.toJSON?.()??null,wall:performance.now()});
      const before=snap();console.timeStamp('measurement:start');await new Promise(r=>setTimeout(r,5000));console.timeStamp('measurement:end');return {before,after:snap()};
    });
    const completion=new Promise(r=>cdp.once('Tracing.tracingComplete',r));await cdp.send('Tracing.end');const {stream}=await completion;
    let trace='';for(;;){const chunk=await cdp.send('IO.read',{handle:stream});trace+=chunk.data;if(chunk.eof)break;}await cdp.send('IO.close',{handle:stream});
    await writeFile(new URL(id+'.trace.json.gz',results),gzipSync(trace));
    await page.evaluate(async()=>{await window.sineExperiment.engine.close();await window.sineExperiment.c.close();delete window.sineExperiment;});
    runs.push({id,round,variant,setup,observation});await writeFile(new URL('browser.json',results),JSON.stringify({metadata,runs},null,2));console.log(id,JSON.stringify(observation));
  }
}finally{
  await page.evaluate(async()=>{if(window.sineExperiment){await window.sineExperiment.engine.close().catch(()=>{});await window.sineExperiment.c.close();}}).catch(()=>{});
  await page.close();await browser.close();
}
