import collections
import gzip
import hashlib
import json
import math
from pathlib import Path

root = Path(__file__).parent
browser = json.loads((root / 'browser-results/browser.json').read_text())
assert len(browser['runs']) == 6
runs = []
for run in browser['runs']:
    events = json.loads(gzip.decompress((root / 'browser-results' / (run['id'] + '.trace.json.gz')).read_bytes()))['traceEvents']
    markers = {key:[e['ts'] for e in events if e.get('name') == 'TimeStamp' and e.get('args',{}).get('data',{}).get('message') == key] for key in ['measurement:start','measurement:end']}
    assert all(len(value) == 1 for value in markers.values())
    start,end = markers['measurement:start'][0],markers['measurement:end'][0]
    calls = [e for e in events if e.get('ph') == 'X' and e.get('name') == 'FunctionCall' and start <= e['ts'] <= end and e.get('args',{}).get('data',{}).get('functionName') == 'process' and e.get('args',{}).get('data',{}).get('url','').endswith('/graph-processor.js')]
    threads = {(e['pid'],e['tid']) for e in calls}
    assert len(threads) == 1 and len(calls) > 1200, run['id']
    thread = next(iter(threads))
    gc = [e for e in events if e.get('ph') == 'X' and e.get('name') in ('MinorGC','MajorGC') and (e['pid'],e['tid']) == thread and start <= e['ts'] <= end]
    before,after = run['observation']['before'],run['observation']['after']
    assert before['state'] == after['state'] == 'running' and after['currentTime']-before['currentTime'] > 4
    durations = sorted(e['dur'] for e in calls)
    stats = {f'p{p}Microseconds':durations[math.ceil(len(durations)*p/100)-1] for p in [50,95,99]}
    runs.append({**run,'windowSeconds':(end-start)/1e6,'callbacks':len(calls),'thread':list(thread),'gcCounts':dict(collections.Counter(e['name'] for e in gc)),'gcWallMilliseconds':sum(e['dur'] for e in gc)/1000,'callbackDuration':stats,'gcEvents':gc})
profiles = []
for path in sorted((root / 'alloc-results').glob('*.json')):
    r = json.loads(path.read_text())
    assert r['wasmSha256'] == browser['metadata']['wasmSha256']['fixed']
    profiles.append({k:r[k] for k in ['id','mode','count','waveform','nodeCount','blocks','wasmSha256','sampledEstimatedBytes']} | {'gcEvents':len(r['gc'])})
assert len(profiles) == 2
comparison = json.loads((root / 'audio-comparison.json').read_text())
assert comparison['fixedSha256'] == browser['metadata']['wasmSha256']['fixed']
assert comparison['originalSha256'] == browser['metadata']['wasmSha256']['baseline']
for variant,expected in browser['metadata']['wasmSha256'].items():
    assert hashlib.sha256((root / 'web' / (variant + '.wasm')).read_bytes()).hexdigest() == expected
record = {'browser':{'metadata':browser['metadata'],'runs':runs},'allocationProfiles':profiles,'audioComparison':comparison,'codegen':json.loads((root / 'sine-codegen.json').read_text())}
print(json.dumps(record,indent=2))
