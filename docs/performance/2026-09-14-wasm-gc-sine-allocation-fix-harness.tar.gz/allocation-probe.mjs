// Standalone V8 isolation of the exact browser release WASM, no AudioWorklet.
// node --expose-gc allocation-probe.mjs MODE COUNT WAVEFORM NODES BLOCKS
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {Session} from 'node:inspector/promises';
import {PerformanceObserver,performance} from 'node:perf_hooks';
import v8 from 'node:v8';
import {createHash} from 'node:crypto';
const mode=process.argv[2]||'process';
const count=Number(process.argv[3]??1);
const waveform=process.argv[4]||'sine';
const nodeCount=Number(process.argv[5]??3);
const blocks=Number(process.argv[6]??10000);
const root=new URL('./',import.meta.url);
await mkdir(new URL('alloc-results/',root),{recursive:true});
const bytes=await readFile(new URL(process.env.WASM_FILE||'web/moonbit_dsp.wasm',root));
const module=await WebAssembly.compile(bytes);
const w=(await WebAssembly.instantiate(module,{spectest:{print_char(){}},'moonbit:ffi':{make_closure(f,c){return f.bind(null,c);}}})).exports;
if(!w.graph_host_init(48000))throw Error('init');
const handles=[];
for(let voice=0;voice<count;voice++){
  const nodes=[{type:'oscillator',waveform,frequency:211+voice*37}];
  for(let i=1;i<nodeCount-1;i++)nodes.push({type:'gain',input:i-1,gain:i===1?0.0005:.992});
  nodes.push({type:'output',input:nodes.length-1});
  w.graph_host_clear_input();for(const ch of JSON.stringify({nodes}))w.graph_host_push_char(ch.codePointAt(0));
  const handle=w.graph_host_mount();if(!handle)throw Error('mount');
  handles.push(handle);
}
if(mode!=='paused')for(const handle of handles)if(!w.graph_host_command(handle,0))throw Error('play');
w.graph_host_process(128);
function run(iterations){
  let sum=0;
  for(let block=0;block<iterations;block++){
    if(mode!=='transfer'&&mode!=='noop') {if(!w.graph_host_process(128))throw Error('process');}
    if(mode==='transfer'||mode==='full')for(let i=0;i<128;i++)sum+=w.graph_host_sample(i);
  }
  return sum;
}
run(2048);global.gc();
const session=new Session();session.connect();
await session.post('HeapProfiler.startSampling',{samplingInterval:32768,includeObjectsCollectedByMajorGC:true,includeObjectsCollectedByMinorGC:true});
const gc=[];
const observer=new PerformanceObserver(list=>{for(const e of list.getEntries())gc.push({kind:e.detail.kind,flags:e.detail.flags,duration:e.duration,startTime:e.startTime});});
observer.observe({entryTypes:['gc']});
await new Promise(setImmediate);
const before=v8.getHeapStatistics();const start=performance.now();
const checksum=run(blocks);const end=performance.now();const after=v8.getHeapStatistics();
const {profile}=await session.post('HeapProfiler.stopSampling');
await new Promise(setImmediate);await new Promise(setImmediate);observer.disconnect();session.disconnect();
const allocations=[];
function walk(node,parents=[]){
  const f=node.callFrame;const frame=`${f.functionName||'(anonymous)'} @ ${f.url}:${f.lineNumber}`;
  const stack=[...parents,frame];
  if(node.selfSize)allocations.push({bytes:node.selfSize,stack});
  for(const child of node.children)walk(child,stack);
}
walk(profile.head);allocations.sort((a,b)=>b.bytes-a.bytes);
const id=`${mode}-g${count}-${waveform}-n${nodeCount}-b${blocks}`;
const record={id,mode,count,waveform,nodeCount,blocks,node:process.version,v8:process.versions.v8,wasmSha256:createHash('sha256').update(bytes).digest('hex'),milliseconds:end-start,checksum,
  heapBefore:before,heapAfter:after,gc:gc.filter(e=>e.startTime>=start&&e.startTime<=end),sampledEstimatedBytes:allocations.reduce((s,a)=>s+a.bytes,0),allocations,profile};
await writeFile(new URL(`alloc-results/${id}.json`,root),JSON.stringify(record,null,2));
console.log(JSON.stringify({id,milliseconds:record.milliseconds,gc:record.gc.length,sampledEstimatedBytes:record.sampledEstimatedBytes,top:allocations.slice(0,6)},null,2));
w.graph_host_close();
