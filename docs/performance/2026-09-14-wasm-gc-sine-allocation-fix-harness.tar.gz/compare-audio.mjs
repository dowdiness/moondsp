import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
const [oldPath,newPath]=process.argv.slice(2);
const oldBytes=await readFile(oldPath),newBytes=await readFile(newPath);
const modules=await Promise.all([oldBytes,newBytes].map(b=>WebAssembly.compile(b)));
const imports={spectest:{print_char(){}},'moonbit:ffi':{make_closure(f,c){return f.bind(null,c);}}};
const cases=[...[0,211,-440,12000,24000,48000,1e-9].map(frequency=>({frequency,count:1,nodes:3})),{frequency:211,count:16,nodes:3},{frequency:440,count:1,nodes:64}];
const records=[];
for(const scenario of cases){
  const instances=await Promise.all(modules.map(m=>WebAssembly.instantiate(m,imports)));
  const engines=instances.map(i=>i.exports);
  for(const w of engines){
    if(!w.graph_host_init(48000))throw Error('init');
    const handles=[];
    for(let voice=0;voice<scenario.count;voice++){
      const nodes=[{type:'oscillator',waveform:'sine',frequency:scenario.frequency+voice*37}];
      for(let i=1;i<scenario.nodes-1;i++)nodes.push({type:'gain',input:i-1,gain:i===1?.0005:.992});
      nodes.push({type:'output',input:nodes.length-1});
      w.graph_host_clear_input();for(const ch of JSON.stringify({nodes}))w.graph_host_push_char(ch.codePointAt(0));
      const handle=w.graph_host_mount();if(!handle)throw Error('mount '+JSON.stringify(scenario));handles.push(handle);
    }
    for(const h of handles)if(!w.graph_host_command(h,0))throw Error('play');
  }
  let checksum=0;
  for(let block=0;block<4096;block++){
    for(const w of engines)if(!w.graph_host_process(128))throw Error('process');
    for(let i=0;i<128;i++){
      const before=engines[0].graph_host_sample(i),after=engines[1].graph_host_sample(i);
      if(!Object.is(before,after))throw Error(JSON.stringify({scenario,block,i,before,after}));
      checksum+=after;
    }
  }
  for(const w of engines)w.graph_host_close();
  records.push({...scenario,samples:4096*128,checksum});
}
const record={originalSha256:createHash('sha256').update(oldBytes).digest('hex'),fixedSha256:createHash('sha256').update(newBytes).digest('hex'),comparedSamples:records.reduce((n,r)=>n+r.samples,0),mismatches:0,cases:records,node:process.version,v8:process.versions.v8};
await writeFile(new URL('audio-comparison.json',import.meta.url),JSON.stringify(record,null,2));console.log(JSON.stringify(record,null,2));
