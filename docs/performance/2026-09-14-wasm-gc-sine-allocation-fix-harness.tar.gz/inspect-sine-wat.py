import hashlib
import json
from pathlib import Path
import re
import sys

path = Path(sys.argv[1])
source = path.read_text()
starts = list(re.finditer(r'^\(func (\$[^\s()]+)', source, re.M))
names = ('sine__for__phase', 'sine__kernel', 'sine__cosine__kernel')
functions = {}
for index, match in enumerate(starts):
    name = match.group(1)
    if any(name.endswith(suffix) for suffix in names):
        functions[name] = source[match.start():starts[index + 1].start()]
assert len(functions) == 3, list(functions)
checks = []
for name, body in functions.items():
    calls = sorted(set(re.findall(r'\((?:return_)?call\s+(\$[^\s()]+)', body)))
    assert set(calls) <= functions.keys(), (name, calls)
    operations = sorted(set(re.findall(r'\(([a-z][a-z0-9_.]*)\b', body)))
    forbidden = [op for op in operations if op.startswith(('struct.', 'array.', 'ref.', 'call_ref', 'call_indirect', 'return_call_ref', 'return_call_indirect', 'cont.'))]
    assert not forbidden, (name, forbidden)
    assert '(ref ' not in body, name
    checks.append({'function':name, 'calls':calls, 'operations':operations, 'heapOperations':forbidden})
root = Path(__file__).parent
(root / 'sine-functions.wat').write_text('\n'.join(functions.values()))
record = {'watSha256':hashlib.sha256(path.read_bytes()).hexdigest(), 'functions':checks}
(root / 'sine-codegen.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
