#include <stddef.h>
#include <stdlib.h>
static int enabled = 0;
static int count = 0;
void *__real_malloc(size_t);
void *__real_calloc(size_t,size_t);
void *__real_realloc(void *,size_t);
void *__wrap_malloc(size_t n) { if (enabled) ++count; return __real_malloc(n); }
void *__wrap_calloc(size_t n,size_t s) { if (enabled) ++count; return __real_calloc(n,s); }
void *__wrap_realloc(void *p,size_t n) { if (enabled) ++count; return __real_realloc(p,n); }
void swap_audit_begin(void) { count = 0; enabled = 1; }
int swap_audit_end(void) { enabled = 0; return count; }

void *__real_mi_malloc(size_t);
void *__wrap_mi_malloc(size_t n) { if (enabled) ++count; return __real_mi_malloc(n); }
