// THROWAWAY transport probe; no editor or source-map implementation.
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const summary = values => {
  if (!values.length) return {count:0};
  const sorted=[...values].sort((a,b)=>a-b);
  return {count:values.length,mean:values.reduce((a,b)=>a+b,0)/values.length,
    p50:sorted[Math.floor(sorted.length*.5)],p95:sorted[Math.floor(sorted.length*.95)],
    p99:sorted[Math.floor(sorted.length*.99)],max:sorted.at(-1)};
};
const workload='stack(note("c3 e3 g3 c4").fast(8).gate(0.2).lpf(1800,2).hpf(80),s("hh*16"),s("bd*4"))';
let active=null;
async function setup() {
  if(active) await close();
  const ctx=new AudioContext({sampleRate:48000,latencyHint:'interactive'});
  const wasmResponse=await fetch('/_build/wasm-gc/release/build/browser/browser.wasm');
  if(!wasmResponse.ok) throw new Error('Build browser release wasm before running');
  const wasmModule=await WebAssembly.compile(await wasmResponse.arrayBuffer());
  const original=await (await fetch('/web/scheduler-processor.js')).text();
  const appended=await (await fetch('/scripts/visualization-probe/worklet.js')).text();
  const moduleSource=original.replace('from "./playback-controller.js"', `from "${location.origin}/web/playback-controller.js"`)+'\n'+appended;
  const url=URL.createObjectURL(new Blob([moduleSource],{type:'application/javascript'}));
  await ctx.audioWorklet.addModule(url);
  const node=new AudioWorkletNode(ctx,'visualization-probe',{
    processorOptions:{wasmModule},numberOfInputs:0,outputChannelCount:[2]});
  const mute=ctx.createGain(); mute.gain.value=0;
  node.connect(mute).connect(ctx.destination);
  const p={ctx,node,url,mute,waiters:new Map(),id:0,latestStatus:null,epoch:0,
    received:0,lastSequence:0,outOfOrder:0,expired:0,visible:0,lags:[],
    statuses:[],errors:[],visualStarts:new Float64Array(4096),visualEnds:new Float64Array(4096),
    visualHead:0,visualCount:0,visualDropped:0,raf:0,rafTimes:[],visibleLateness:[]};
  active=p;
  function wait(type,id='') {
    return new Promise((resolve,reject)=>{
      const key=`${type}:${id}`;
      const timer=setTimeout(()=>{p.waiters.delete(key);reject(new Error(`timeout ${key}`));},15000);
      p.waiters.set(key,{resolve:x=>{clearTimeout(timer);resolve(x)},reject:e=>{clearTimeout(timer);reject(e)}});
    });
  }
  p.command=async(type,fields={},reply='probe-report')=>{
    const id=++p.id; const promise=wait(reply,id);
    node.port.postMessage({type,id,...fields});
    const result=await promise;
    if(result.accepted===false) throw new Error(result.message);
    return result;
  };
  function listenerTime(frame) {
    const stamp=ctx.getOutputTimestamp?.();
    return stamp && stamp.contextTime>0 && stamp.performanceTime>0
      ? stamp.performanceTime+(frame/ctx.sampleRate-stamp.contextTime)*1000
      : performance.now()+(frame/ctx.sampleRate-ctx.currentTime+(ctx.baseLatency||0)+(ctx.outputLatency||0))*1000;
  }
  function tick(now) {
    p.rafTimes.push(now);
    while(p.visualCount) {
      const i=p.visualHead;
      if(now<p.visualStarts[i])break;
      p.visualHead=(i+1)%4096;p.visualCount--;
      if(now>=p.visualEnds[i])p.expired++;
      else {p.visible++;p.visibleLateness.push(now-p.visualStarts[i]);}
    }
    p.raf=requestAnimationFrame(tick);
  }
  node.port.onmessage=({data})=>{
    if(data.type==='error') {
      p.errors.push(data.message);
      for(const w of p.waiters.values()) w.reject(new Error(data.message));
      p.waiters.clear();return;
    }
    if(data.type==='player-status') {p.latestStatus=data;return;}
    if(data.type==='probe-batch') {
      const values=new Float64Array(data.buffer);
      if(data.epoch===p.epoch) {
        const receivedAt=performance.now();
        for(let n=0;n<data.count;n++) {
          const i=n*8,seq=values[i+5],frame=values[i+4];
          if(seq<=p.lastSequence)p.outOfOrder++;
          p.lastSequence=seq;p.received++;
          // Receipt lag against render-head time; not physical audible latency.
          p.lags.push((ctx.currentTime-frame/ctx.sampleRate)*1000);
          const start=listenerTime(frame),end=start+150;
          if(end<=receivedAt){p.expired++;continue;}
          if(p.visualCount===4096){p.visualHead=(p.visualHead+1)%4096;p.visualCount--;p.visualDropped++;}
          const at=(p.visualHead+p.visualCount)%4096;
          p.visualStarts[at]=start;p.visualEnds[at]=end;p.visualCount++;
        }
      }
      node.port.postMessage({type:'probe-credit',epoch:data.epoch,sequence:data.sequence,buffer:data.buffer},[data.buffer]);
      return;
    }
    if(data.type==='probe-started')p.epoch=data.epoch;
    const key=`${data.type}:${data.id??''}`;
    const w=p.waiters.get(key);if(w){p.waiters.delete(key);w.resolve(data);}
  };
  node.onprocessorerror=()=>{p.errors.push('processorerror');};
  const ready=wait('ready');
  await ctx.resume();await ready;
  await p.command('player-restart',{text:workload},'player-receipt');
  await sleep(1500);
  p.raf=requestAnimationFrame(tick);
  return {sampleRate:ctx.sampleRate,baseLatency:ctx.baseLatency,outputLatency:ctx.outputLatency,
    outputTimestamp:ctx.getOutputTimestamp?.(),playbackStats:ctx.playbackStats?.toJSON?.()??null,
    crossOriginIsolated,visibility:document.visibilityState,userAgent:navigator.userAgent,workload};
}
async function run(options) {
  const p=active;
  const before={time:p.ctx.currentTime,wall:performance.now(),stats:p.ctx.playbackStats?.toJSON?.()??null};
  const started=await p.command('probe-start',{enabled:options.variant==='batch',
    perBlock:options.recordsPerBlock,every:options.everyBlocks},'probe-started');
  console.timeStamp('visualization:measurement-start');
  let stall=null;
  if(options.stallMilliseconds) stall=setTimeout(()=>{
    console.timeStamp('visualization:stall-start');
    const end=performance.now()+options.stallMilliseconds;
    while(performance.now()<end) { /* controlled main-thread stall */ }
    console.timeStamp('visualization:stall-end');
  },2000);
  await sleep(options.windowMilliseconds??5000);
  console.timeStamp('visualization:measurement-end');
  await p.command('probe-stop',{},'probe-stopped');
  clearTimeout(stall);
  const after={time:p.ctx.currentTime,wall:performance.now(),stats:p.ctx.playbackStats?.toJSON?.()??null};
  await sleep(200);
  const report=await p.command('probe-report');
  const raw=report;
  const result={options,before,after,started,
    report:{...report,costs:summary(report.costs),gaps:summary(report.gaps)},
    consumer:{received:p.received,outOfOrder:p.outOfOrder,expired:p.expired,visible:p.visible,
      queued:p.visualCount,visualDropped:p.visualDropped,visibleLatenessMs:summary(p.visibleLateness),
      receiptLagMs:summary(p.lags),lastStatus:p.latestStatus,errors:p.errors,
      frameGapMs:summary(p.rafTimes.slice(1).map((x,i)=>x-p.rafTimes[i]))},
    limitation:'Synthetic records over real DSP. No origin lookup, CodeMirror decoration, MoonBit enqueue, or physical listening verified.'};
  result.correctness={bounded:report.maxInFlight<=1&&report.peakBuffered<=64&&!report.timingOverflow,
    accounting:options.variant==='off'||report.produced===p.received+report.dropped+report.count,
    ordered:p.outOfOrder===0,settled:report.inFlight===0&&report.count===0,
    finiteAudio:report.nonfinite===0&&report.energy>0,
    consumerSafe:p.visibleLateness.every(ms=>ms>=0&&ms<150),
    visualActivity:options.variant==='off'||p.visible>0};
  document.querySelector('pre').textContent=JSON.stringify(result,null,2);
  return {result,raw};
}
async function close(){
  const p=active;if(!p)return;active=null;
  cancelAnimationFrame(p.raf);p.node.disconnect();p.mute.disconnect();p.node.port.close();
  await p.ctx.close();URL.revokeObjectURL(p.url);
  for(const w of p.waiters.values())w.reject(new Error('probe closed'));p.waiters.clear();
}
window.visualizationProbe={setup,run,close};
document.querySelector('button').onclick=async()=>{
  try{await setup();await run({variant:'batch',recordsPerBlock:16,everyBlocks:1});}
  catch(e){document.querySelector('pre').textContent=String(e);}
  finally{await close();}
};
