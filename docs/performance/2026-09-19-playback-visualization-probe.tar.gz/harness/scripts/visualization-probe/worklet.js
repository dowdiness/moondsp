// THROWAWAY. Appended to the production scheduler module by page.js.
// Records are synthetic: this isolates transport, not source-provenance integration.
class VisualizationProbe extends MoonDspSchedulerProcessor {
  constructor(options) {
    super(options);
    this.capacity = 64;
    this.width = 8;
    this.ring = new Float64Array(this.capacity * this.width);
    this.credit = new Float64Array(this.capacity * this.width);
    this.readIndex = 0;
    this.count = 0;
    this.pendingSequence = 0;
    this.sentSequence = 0;
    this.inFlight = 0;
    this.maxInFlight = 0;
    this.epoch = 0;
    this.activeProbe = false;
    this.enabled = false;
    this.produced = 0;
    this.dropped = 0;
    this.sentRecords = 0;
    this.messages = 0;
    this.acks = 0;
    this.blocks = 0;
    this.peakBuffered = 0;
    this.nonfinite = 0;
    this.energy = 0;
    this.frames = 0;
    this.costs = new Float64Array(32768);
    this.gaps = new Float64Array(32768);
    this.previousWall = 0;
  }
  dispatchCommand(data) {
    if (data.type === 'probe-credit') {
      if (data.epoch !== this.epoch || data.sequence !== this.pendingSequence || !this.inFlight) {
        throw new Error('Invalid transport credit');
      }
      this.credit = new Float64Array(data.buffer);
      this.inFlight = 0;
      this.acks++;
      return;
    }
    if (data.type === 'probe-start') {
      if (this.inFlight || this.count) throw new Error('Unsettled prior probe');
      this.epoch++;
      this.enabled = data.enabled;
      this.perBlock = data.perBlock;
      this.every = data.every;
      this.readIndex = 0;
      this.blocks = 0;
      this.produced = this.dropped = this.sentRecords = this.messages = this.acks = 0;
      this.energy = this.frames = this.nonfinite = 0;
      this.maxInFlight = this.peakBuffered = 0;
      this.previousWall = 0;
      this.activeProbe = true;
      this.port.postMessage({type:'probe-started', epoch:this.epoch, id:data.id,
        frame:currentFrame, time:currentTime, clock:typeof performance});
      return;
    }
    if (data.type === 'probe-stop') {
      this.activeProbe = false;
      this.port.postMessage({type:'probe-stopped', id:data.id});
      return;
    }
    if (data.type === 'probe-report') {
      this.port.postMessage({type:'probe-report', id:data.id, epoch:this.epoch,
        produced:this.produced, dropped:this.dropped, sentRecords:this.sentRecords,
        messages:this.messages, acks:this.acks, count:this.count, inFlight:this.inFlight,
        maxInFlight:this.maxInFlight, peakBuffered:this.peakBuffered,
        blocks:this.blocks, frames:this.frames, nonfinite:this.nonfinite, energy:this.energy,
        costs:Array.from(this.costs.subarray(0,Math.min(this.blocks,this.costs.length))),
        gaps:Array.from(this.gaps.subarray(0,Math.min(this.blocks,this.gaps.length))),
        timingOverflow:this.blocks>this.costs.length});
      return;
    }
    super.dispatchCommand(data);
  }
  enqueue(frame) {
    for (let n=0;n<this.perBlock;n++) {
      const seq = ++this.produced;
      if (!this.enabled) continue;
      if (this.count === this.capacity) {
        this.readIndex = (this.readIndex+1)%this.capacity;
        this.count--;
        this.dropped++;
      }
      const i = ((this.readIndex+this.count)%this.capacity)*this.width;
      this.ring[i] = this.epoch;
      this.ring[i+1] = Math.floor(this.blocks/375); // varying synthetic version
      this.ring[i+2] = seq%97;
      this.ring[i+3] = seq%7;
      this.ring[i+4] = frame;
      this.ring[i+5] = seq;
      this.ring[i+6] = 0;
      this.ring[i+7] = n;
      this.count++;
    }
    if(this.count>this.peakBuffered) this.peakBuffered=this.count;
  }
  flush() {
    if (!this.enabled || !this.count || this.inFlight) return;
    const count = this.count;
    for(let n=0;n<count;n++) {
      const from=((this.readIndex+n)%this.capacity)*this.width;
      const to=n*this.width;
      for(let k=0;k<this.width;k++) this.credit[to+k]=this.ring[from+k];
    }
    this.count=0;
    this.readIndex=0;
    this.pendingSequence=++this.sentSequence;
    this.inFlight=1;
    this.maxInFlight=1;
    this.sentRecords+=count;
    this.messages++;
    const buffer=this.credit.buffer;
    this.credit=null;
    this.port.postMessage({type:'probe-batch',epoch:this.epoch,sequence:this.pendingSequence,
      count,buffer},[buffer]);
  }
  process(inputs,outputs,parameters) {
    const started=Date.now();
    const ok=super.process(inputs,outputs,parameters);
    if(this.activeProbe) {
      if(this.blocks%this.every===0) this.enqueue(currentFrame);
      this.flush();
      const left=outputs[0]?.[0];
      if(left) for(let n=0;n<left.length;n++) {
        const value=left[n];
        if(!Number.isFinite(value)) this.nonfinite++;
        this.energy+=value*value;
        this.frames++;
      }
      if(this.blocks<this.costs.length) {
        this.costs[this.blocks]=Date.now()-started;
        this.gaps[this.blocks]=this.previousWall ? started-this.previousWall : 0;
      }
      this.previousWall=started;
      this.blocks++;
    } else {
      this.flush();
    }
    return ok;
  }
}
registerProcessor('visualization-probe',VisualizationProbe);
