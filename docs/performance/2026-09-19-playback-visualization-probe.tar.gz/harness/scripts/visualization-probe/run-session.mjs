// THROWAWAY. Invoke runSession(page, repositoryPath, selection) from a Puppeteer page.
import {readFile,writeFile,mkdir} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
import {createHash} from 'node:crypto';
function stats(values) {
  if(!values.length)return {count:0};
  const a=[...values].sort((x,y)=>x-y);
  return {count:a.length,mean:a.reduce((x,y)=>x+y,0)/a.length,p50:a[Math.floor(a.length*.5)],
    p95:a[Math.floor(a.length*.95)],p99:a[Math.floor(a.length*.99)],max:a.at(-1)};
}
export function summarizeTrace(text) {
  const events=JSON.parse(text).traceEvents;
  const marker=name=>events.find(e=>e.name==='TimeStamp'&&e.args?.data?.message===name)?.ts;
  const start=marker('visualization:measurement-start'),end=marker('visualization:measurement-end');
  if(start===undefined||end===undefined)throw new Error('Missing measurement markers');
  const window=events.filter(e=>e.ts>=start&&e.ts<=end);
  const calls=window.filter(e=>e.ph==='X'&&e.name==='FunctionCall'&&
    e.args?.data?.functionName==='process'&&e.args?.data?.url?.startsWith('blob:'));
  const threads=[...new Set(calls.map(e=>`${e.pid}:${e.tid}`))];
  const thread=threads.length===1?threads[0]:null;
  const same=e=>thread!==null&&`${e.pid}:${e.tid}`===thread;
  const gc=window.filter(e=>same(e)&&e.ph==='X'&&(e.name==='MinorGC'||e.name==='MajorGC'));
  const glitch=window.filter(e=>/Glitch|Underrun/i.test(e.name));
  const heaps=window.filter(e=>same(e)&&e.args&&(e.args.usedHeapSizeBefore!==undefined||e.args.usedHeapSizeAfter!==undefined));
  return {windowUs:end-start,processorThreads:threads,
    callbackMs:stats(calls.map(e=>e.dur/1000)),
    gc:gc.map(e=>({name:e.name,ts:e.ts,durationMs:e.dur/1000,args:e.args})),
    gcDurationMs:gc.reduce((sum,e)=>sum+e.dur/1000,0),
    glitchEvents:glitch.map(e=>({name:e.name,pid:e.pid,tid:e.tid,ts:e.ts,args:e.args})),
    heapEvents:heaps.map(e=>({name:e.name,args:e.args})),
    traceEventCount:window.length,
    missingCallbackEvidence:thread===null,
    allocationByteAttribution:'No worklet-isolate allocation sampler; GC heap args are not cumulative allocated bytes'};
}
export async function runSession(page,root,selection={}) {
  const criteria=JSON.parse(await readFile(root+'/scripts/visualization-probe/criteria.json','utf8'));
  const out=root+'/_build/visualization-probe';await mkdir(out,{recursive:true});
  const cdp=await page.target().createCDPSession();
  const categories='webaudio,audio,blink.console,devtools.timeline,v8,disabled-by-default-v8.gc';
  const browserVersion=await cdp.send('Browser.getVersion');
  const files=['web/scheduler-processor.js','web/playback-controller.js','scripts/visualization-probe/worklet.js',
    'scripts/visualization-probe/page.js','_build/wasm-gc/release/build/browser/browser.wasm'];
  const hashes={};for(const f of files)hashes[f]=createHash('sha256').update(await readFile(root+'/'+f)).digest('hex');
  const metadata={date:new Date().toISOString(),criteria,browserVersion,hashes,categories,
    rendering:'Real production scheduler, output gain muted but connected to destination',
    observation:'Synthetic varying records for transport isolation, not scheduled note provenance'};
  const runs=[];
  const scenarios=criteria.scenarios.filter(s=>!selection.scenario||s.name===selection.scenario);
  try {
    for(let round=0;round<(selection.rounds??criteria.rounds);round++) {
      for(const scenario of scenarios) {
        for(const variant of (round%2?['batch','off']:['off','batch'])) {
          const id=`${selection.trace===false?'untraced':'traced'}-${scenario.name}-r${round}-${variant}`;
          await page.reload({waitUntil:'load'});
          await page.waitForFunction(()=>!!window.visualizationProbe);
          const setup=await page.evaluate(()=>window.visualizationProbe.setup());
          const options={...scenario,variant,windowMilliseconds:criteria.windowMilliseconds};
          let traced=selection.trace!==false;
          if(traced)await cdp.send('Tracing.start',{categories,transferMode:'ReturnAsStream'});
          const measured=await page.evaluate(options=>window.visualizationProbe.run(options),options);
          let traceSummary=null;
          if(traced) {
            const finished=new Promise(resolve=>cdp.once('Tracing.tracingComplete',resolve));
            await cdp.send('Tracing.end');const {stream}=await finished;
            let trace='';
            for(;;){const chunk=await cdp.send('IO.read',{handle:stream});trace+=chunk.data;if(chunk.eof)break;}
            await cdp.send('IO.close',{handle:stream});
            await writeFile(out+'/'+id+'.trace.json.gz',gzipSync(trace));
            traceSummary=summarizeTrace(trace);
          }
          await page.evaluate(()=>window.visualizationProbe.close());
          await writeFile(out+'/'+id+'.raw.json',JSON.stringify(measured.raw));
          const record={id,round,scenario:scenario.name,variant,setup,...measured.result,trace:traceSummary};
          runs.push(record);
          await writeFile(out+`/${selection.trace===false?'untraced':'traced'}-results.json`,JSON.stringify({metadata,runs},null,2));
          console.log(id,JSON.stringify({correctness:record.correctness,received:record.consumer.received,
            dropped:record.report.dropped,visible:record.consumer.visible,expired:record.consumer.expired,
            receiptP95:record.consumer.receiptLagMs.p95,callbackP99:traceSummary?.callbackMs.p99,
            gc:traceSummary?.gc.length,underruns:record.after.stats?.underrunEvents-record.before.stats?.underrunEvents}));
        }
      }
    }
  } finally {
    await page.evaluate(()=>window.visualizationProbe?.close()).catch(()=>{});
    await cdp.detach();
  }
  return {metadata,runs};
}
