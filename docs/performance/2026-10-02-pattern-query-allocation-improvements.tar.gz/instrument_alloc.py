#!/usr/bin/env python3
"""Instrument normalized folded WAT GC allocations; not for timing measurements.
Counters represent executed GC allocation instructions and logical payload only,
not V8 heap bytes, object headers/alignment, JS allocations or GC pause duration.
"""
import collections, json, pathlib, re, subprocess, sys
TOKEN = re.compile(r'"(?:[^"\\]|\\.)*"|;;[^\n]*|[()]|[^\s()"]+')
class Node:
    __slots__ = ('start','end','items')
    def __init__(self, start): self.start=start; self.end=0; self.items=[]
    @property
    def head(self): return self.items[0] if self.items and isinstance(self.items[0],str) else ''
def parse(text):
    roots=[]; stack=[]
    for match in TOKEN.finditer(text):
        token=match.group()
        if token.startswith(';;'): continue
        if token=='(':
            node=Node(match.start())
            (stack[-1].items if stack else roots).append(node); stack.append(node)
        elif token==')':
            stack.pop().end=match.end()
        else: stack[-1].items.append(token)
    assert not stack
    return roots

def walk(node):
    yield node
    for item in node.items:
        if isinstance(item,Node): yield from walk(item)

def scalar_shape(node):
    if isinstance(node,str):
        return {'i8':(1,0),'i16':(2,0),'i32':(4,0),'i64':(8,0),'f32':(4,0),'f64':(8,0),'v128':(16,0)}[node]
    if node.head=='ref': return (0,1)
    if node.head in ('mut','field'): return scalar_shape(node.items[-1])
    raise ValueError(node.head)

def instrument(source, output):
    text=pathlib.Path(source).read_text(); roots=parse(text)
    assert len(roots)==1 and roots[0].head=='module'; module=roots[0]
    types={}
    for node in walk(module):
        if node.head!='type' or len(node.items)<3:continue
        definition=node.items[2]
        if not isinstance(definition,Node):continue
        shape=next((n for n in walk(definition) if n.head in ('struct','array')),None)
        if shape is None:continue
        if shape.head=='struct':
            fields=[scalar_shape(f) for f in shape.items[1:]]
            sb=sum(f[0] for f in fields); refs=sum(f[1] for f in fields)
        else: sb,refs=scalar_shape(shape.items[-1])
        types[node.items[1]]={'kind':shape.head,'scalarBytes':sb,'referenceSlots':refs,'definition':text[node.start:node.end]}
    insert=collections.defaultdict(list); metadata=[]; globals_=[]; helpers=[]; indices={}; sites=0
    operations={'struct.new','struct.new_default','array.new','array.new_default','array.new_fixed','array.new_data','array.new_elem'}
    # Only function bodies: global constant initializers cannot call counter helpers.
    funcs=[n for n in module.items if isinstance(n,Node) and n.head=='func']
    for fn in funcs:
        for node in walk(fn):
            if node.head not in operations:continue
            typ=node.items[1]; shape=types[typ]
            if typ not in indices:
                i=len(indices);indices[typ]=i
                metadata.append({'index':i,'type':typ,**shape})
                globals_.append(f'(global $__ac{i} (mut i64) (i64.const 0)) (global $__ae{i} (mut i64) (i64.const 0))')
                helpers.append(f'(func (export "__alloc_count_{i}") (result f64) (f64.convert_i64_u (global.get $__ac{i})))')
                helpers.append(f'(func (export "__alloc_elements_{i}") (result f64) (f64.convert_i64_u (global.get $__ae{i})))')
                helpers.append(f'(func $__alen{i} (param $n i32) (result i32) (global.set $__ae{i} (i64.add (global.get $__ae{i}) (i64.extend_i32_u (local.get $n)))) (local.get $n))')
            i=indices[typ]; sites+=1
            result_type=f'(exact {typ})' if node.head.startswith('struct.new') else typ
            before=f'(block (result (ref {result_type})) (global.set $__ac{i} (i64.add (global.get $__ac{i}) (i64.const 1))) '
            if node.head=='array.new_fixed':
                length=int(node.items[2]);before+=f'(global.set $__ae{i} (i64.add (global.get $__ae{i}) (i64.const {length}))) '
            elif node.head.startswith('array.new'):
                arg=node.items[-1]; assert isinstance(arg,Node),node.head
                insert[arg.start].append(f'(call $__alen{i} ');insert[arg.end].insert(0,')')
            insert[node.start].append(before);insert[node.end].insert(0,')')
    # Insert globals/functions just before module closer, leaving original type names intact.
    insert[module.end-1].append('\n'+'\n'.join(globals_+helpers)+'\n')
    result=[];last=0
    for pos in sorted(insert):result.extend([text[last:pos],''.join(insert[pos])]);last=pos
    result.append(text[last:]);pathlib.Path(output).write_text(''.join(result))
    meta={'allocationSites':sites,'types':metadata,'semantics':'Executed nontrapping function-body GC allocation operations; excludes module global initializers. Scalar bytes and reference slots are logical payload, not heap bytes.'}
    pathlib.Path(str(output)+'.json').write_text(json.dumps(meta,indent=2))
    print(json.dumps({'output':str(output),'allocationSites':sites,'allocationTypes':len(metadata)}))
if __name__=='__main__':instrument(sys.argv[1],sys.argv[2])
