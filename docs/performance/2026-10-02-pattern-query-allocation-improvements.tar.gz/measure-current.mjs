import {readFile,writeFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root=new URL('.',import.meta.url),arm=process.argv[2]??'before',wires=JSON.parse(await readFile(new URL('profile-wires.json',root),'utf8'));
const input=text=>JSON.stringify({schema:1,kind:'text',text});
const scenarios=[
  {name:'dense',wire:wires.dense,blocks:600},
  {name:'sparse',wire:wires.sparse,blocks:600},
  {name:'dense-text',wire:input(JSON.parse(wires.dense).text),blocks:600},
  {name:'fractional-update',wire:input('note("60 62 64").fast(7).slow(3)'),update:input('note("67 69 71").fast(5).slow(7)'),blocks:600,controls:true},
  {name:'rest-degrade-zero-gain',wire:input('stack(note("~ ~ 60 ~"), note("60 64").gain(0), note("60 62 64 67").degradeBy(0.35))'),blocks:600,controls:true},
];
const imports={spectest:{print_char(){}},'moonbit:ffi':{make_closure(fn,c){return fn.bind(null,c);}}};
const binary=await readFile(new URL(`harness/current-${arm}.wasm`,root)),counted=await readFile(new URL(`harness/current-${arm}-counted.wasm`,root)),meta=JSON.parse(await readFile(new URL(`current-${arm}-counted.wat.json`,root),'utf8'));
async function run(bytes,scenario,instrumented){
  const {instance}=await WebAssembly.instantiate(bytes,imports),e=instance.exports;
  assert(e.init_scheduler_graph(48000,128));
  function stage(wire){e.clear_playback_input();for(let i=0;i<wire.length;i++)e.push_playback_char(wire.charCodeAt(i));}
  stage(scenario.wire);assert.equal(e.player_restart_input(),0);assert.equal(e.player_play(),0);
  const counts=instrumented?meta.map(x=>e['__fc_'+x.index]()):[],pcm=new Float32Array(scenario.blocks*256),states=[];
  for(let b=0;b<scenario.blocks;b++){
    if(scenario.controls){
      if(b===48)assert.equal(e.set_scheduler_bpm(137),0);
      if(b===80&&scenario.update){stage(scenario.update);assert.equal(e.player_update_input(),0);}
      if(b===120)assert.equal(e.player_pause(),0);
      if(b===124)assert.equal(e.player_play(),0);
      if(b===160){stage(scenario.wire);assert.equal(e.player_restart_input(),0);assert.equal(e.player_play(),0);}
      if(b===280)assert.equal(e.set_scheduler_bpm(83.125),0);
    }
    assert(e.process_scheduler_block());
    for(let i=0;i<128;i++){pcm[b*256+i*2]=e.scheduler_left_sample(i);pcm[b*256+i*2+1]=e.scheduler_right_sample(i);}
    if(!instrumented)states.push([e.player_state(),e.player_pending_count(),e.player_skipped_count(),e.scheduler_bpm(),e.scheduler_sample_position(),e.scheduler_cycle_position()]);
  }
  let sum=0,energy=0,peak=0;for(const x of pcm){sum+=x;energy+=x*x;peak=Math.max(peak,Math.abs(x));}
  const rows=instrumented?meta.map(x=>({...x,count:e['__fc_'+x.index]()-counts[x.index]})).filter(x=>x.count).sort((a,b)=>b.count-a.count):[];
  return{pcm,states,rows,total:rows.reduce((s,x)=>s+x.count,0),sha256:createHash('sha256').update(new Uint8Array(pcm.buffer)).digest('hex'),sum,energy,peak};
}
const report={arm,settings:{sampleRate:48000,blockSize:128},binarySha256:createHash('sha256').update(binary).digest('hex'),scenarios:[]};
for(const scenario of scenarios){
  const original=await run(binary,scenario,false),measured=await run(counted,scenario,true);
  assert.deepEqual(measured.pcm,original.pcm,scenario.name+' instrumentation PCM');
  await writeFile(new URL(`current-${arm}-${scenario.name}.pcm`,root),new Uint8Array(original.pcm.buffer));
  report.scenarios.push({name:scenario.name,blocks:scenario.blocks,pcmEqual:true,pcmSha256:original.sha256,audio:{sum:original.sum,energy:original.energy,peak:original.peak},states:original.states,total:measured.total,rows:measured.rows});
}
await writeFile(new URL(`current-${arm}-results.json`,root),JSON.stringify(report,null,2));
console.log(JSON.stringify({...report,scenarios:report.scenarios.map(({states,rows,...s})=>s)}));
