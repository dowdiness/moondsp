import http from 'node:http';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
const root=path.dirname(fileURLToPath(import.meta.url));
const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.wasm':'application/wasm','.json':'application/json'};
const server=http.createServer(async(req,res)=>{
  res.setHeader('Cross-Origin-Opener-Policy','same-origin');res.setHeader('Cross-Origin-Embedder-Policy','require-corp');res.setHeader('Cross-Origin-Resource-Policy','same-origin');
  try{const url=new URL(req.url,'http://localhost'),rel=decodeURIComponent(url.pathname).replace(/^\/+/, '')||'index.html',file=path.resolve(root,rel);if(file!==root&&!file.startsWith(root+path.sep))throw Object.assign(new Error('forbidden'),{statusCode:403});const bytes=await fs.readFile(file);res.writeHead(200,{'Content-Type':types[path.extname(file)]||'application/octet-stream','Cache-Control':'no-store'});res.end(bytes);}catch(e){res.writeHead(e.statusCode||404,{'Content-Type':'text/plain'});res.end(e.statusCode===403?'Forbidden':'Not found');}
});
const port=Number(process.env.PORT||8765);server.listen(port,'127.0.0.1',()=>console.log(`Harness at http://127.0.0.1:${port}/`));
