// Isolated experiment: requested 48 kHz, standard 128-frame render quantum.
// Probe transport: 4 SAB slots, each 16,384 Int32 words; states FREE=0, WRITING=1,
// The completion message is common to every arm; DSP runs for exactly targetBlocks.
class RealOnsetProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const p=options.processorOptions;
    this.module=p.module; this.variant=p.variant; this.wire=p.wire; this.capacity=p.capacity;
    this.renderMode=p.renderMode??'aggregate';
    this.observe=this.variant==='on'||this.variant==='overflow'||this.variant==='stalledUI';
    this.probeMode=p.probeMode??'copy';this.probeChecksum=0;this.allocBytes=p.allocBytes??0;this.nativeBytes=p.nativeBytes??0;this.allocRetention=p.allocRetention??'retained';
    this.allocationControl=this.allocBytes>0||this.nativeBytes>0?new Array(this.allocRetention==='ring'?8:4096):null;this.allocationCursor=0;this.targetBlocks=0;
    this.evictions=0;
    this.ready=false; this.go=0; this.failed=0; this.blocks=0; this.silentBlocks=0; this.nonzero=0;
    this.sum=0; this.energy=0; this.peak=0; this.missedSlots=0; this.slotWords=p.slotWords; this.slotCount=p.slotCount;
    this.states=new Int32Array(p.sab,0,this.slotCount);
    this.lengths=new Int32Array(p.sab,this.slotCount*4,this.slotCount);
    this.payload=new Int32Array(p.sab,this.slotCount*8); this.writeCursor=0; this.lastFrame=0; this.maxClockStep=0;
    this.localCopy=new Int32Array(this.slotWords);
    this.port.onmessage=event=>{
      const type=event.data?.type;
      if(type==='go') {this.targetBlocks=event.data.blocks??0;this.go=1;}
      if(type==='stop') {this.go=0;this.port.postMessage({type:'stop'});}
      if(type==='reset') {
        try {
          if(this.go)throw new Error('reset requires paused processor');
          this.exports.probe_configure?.(this.observe?1:0,this.capacity);
          this.exports.clear_playback_input();
          for(let i=0;i<this.wire.length;i++)this.exports.push_playback_char(this.wire.charCodeAt(i));
          if(this.exports.player_restart_input()!==0||this.exports.player_play()!==0)throw new Error('reset scheduler failed');
          this.blocks=this.silentBlocks=this.nonzero=this.sum=this.energy=this.peak=this.missedSlots=this.evictions=this.probeChecksum=0;
          this.queryAtStart=this.exports.__query_alloc?.()??0;
          this.otherAtStart=this.exports.__other_alloc?.()??0;
          this.lastFrame=this.maxClockStep=0;
          this.port.postMessage({type:'reset'});
        } catch(error) {this.port.postMessage({type:'failure',message:String(error)});}
      }
      if(type==='finish') {
        this.go=0; const e=this.exports;
        this.port.postMessage({type:'finished',blocks:this.blocks,silentBlocks:this.silentBlocks,nonzero:this.nonzero,
          sum:this.sum,energy:this.energy,peak:this.peak,clockFrame:this.lastFrame,maxClockStep:this.maxClockStep,
          queryAlloc:(e.__query_alloc?.()??0)-(this.queryAtStart??0),otherAlloc:(e.__other_alloc?.()??0)-(this.otherAtStart??0),
          missedSlots:this.missedSlots,evictions:this.evictions,probeChecksum:this.probeChecksum,
          dispatch:e?.probe_dispatch_count?.()??0,records:e?.probe_record_count?.()??0,
          dropped:e?.probe_drop_count?.()??0,run:e?.probe_run?.()??0,failed:this.failed});
      }
    };
    this.initialize();
  }
  async initialize() {
    try {
      const result=await WebAssembly.instantiate(this.module,{spectest:{print_char(){}},'moonbit:ffi':{make_closure(fn,closure){return fn.bind(null,closure);}}});
      const instance=result instanceof WebAssembly.Instance?result:result.instance;
      this.exports=instance.exports; const e=this.exports;
      const required=['init_scheduler_graph','process_scheduler_block','scheduler_left_sample','scheduler_right_sample','clear_playback_input','push_playback_char','player_restart_input','player_play'];
      for(const key of required) if(typeof e[key]!=='function') throw new Error(`Missing export: ${key}`);
      const probeNames=['probe_configure','probe_word_count','probe_word','probe_dispatch_count','probe_record_count','probe_drop_count','probe_run'];
      if(this.variant!=='baseline')for(const key of probeNames)if(typeof e[key]!=='function')throw new Error(`Missing probe export: ${key}`);
      if(!e.init_scheduler_graph(sampleRate,128)) throw new Error('Graph init failed');
      if(e.probe_configure)e.probe_configure(['on','overflow','stalledUI'].includes(this.variant)?1:0,this.capacity);
      e.clear_playback_input(); for(let i=0;i<this.wire.length;i++) e.push_playback_char(this.wire.charCodeAt(i));
      if(e.player_restart_input()!==0) throw new Error('Scheduler restart rejected wire');
      if(e.player_play()!==0) throw new Error('Scheduler play failed');
      this.ready=true; this.port.postMessage({type:'ready'});
    } catch(error) { this.failed=1; this.port.postMessage({type:'failure',message:String(error)}); }
  }
  readSamples(left,right) {
    const e=this.exports;
    for(let i=0;i<left.length;i++){left[i]=e.scheduler_left_sample(i);if(right)right[i]=e.scheduler_right_sample(i);}
  }
  aggregateSamples(left,right) {
    const e=this.exports;let blockEnergy=0;
    for(let i=0;i<left.length;i++){
      const l=e.scheduler_left_sample(i),r=e.scheduler_right_sample(i);left[i]=l;if(right)right[i]=r;
      this.sum=(this.sum+l+r)%2147483647;blockEnergy+=l*l+r*r;this.peak=Math.max(this.peak,Math.abs(l),Math.abs(r));
      if(l!==0)this.nonzero++;if(r!==0)this.nonzero++;
    }
    this.energy+=blockEnergy;if(blockEnergy===0)this.silentBlocks++;
  }
  process(_inputs,outputs) {
    const out=outputs[0]; if(!out||!out[0]) return true;
    const left=out[0],right=out[1];
    if(!this.ready||!this.go){left.fill(0);if(right)right.fill(0);return true;}
    const e=this.exports;
    if(this.renderMode!=='silence'&&!e.process_scheduler_block()){this.failed=1;left.fill(0);if(right)right.fill(0);return true;}
    if(this.renderMode==='silence'||this.renderMode==='dsp'){left.fill(0);if(right)right.fill(0);}
    else if(this.renderMode==='samples')this.readSamples(left,right);
    else this.aggregateSamples(left,right);
    this.blocks++;
    const frame=currentFrame;if(this.lastFrame&&frame>this.lastFrame)this.maxClockStep=Math.max(this.maxClockStep,frame-this.lastFrame);this.lastFrame=frame;
    if(this.observe){
      if(this.probeMode==='copy')this.copyProbe();
      else if(this.probeMode==='copySlots')this.copyProbe(false);
      else if(this.probeMode==='copyLocal'){const count=e.probe_word_count();for(let i=0;i<count;i++)this.localCopy[i]=e.probe_word(i);this.probeChecksum+=this.localCopy[0];}
      else if(this.probeMode==='count')this.probeChecksum+=e.probe_word_count();
      else if(this.probeMode==='read'){const count=e.probe_word_count();for(let i=0;i<count;i++)this.probeChecksum=(this.probeChecksum+e.probe_word(i))|0;}
    }
    if(this.allocBytes>0){
      const blob=new Array(this.allocBytes);
      for(let i=0;i<blob.length;i++)blob[i]=(this.blocks+i)&255;
      if(this.allocRetention!=='transient')this.allocationControl[(this.allocationCursor++)%this.allocationControl.length]=blob;
      else this.probeChecksum+=blob[this.blocks%blob.length];
    }
    if(this.nativeBytes>0){
      const buffer=new ArrayBuffer(this.nativeBytes);
      new Uint8Array(buffer)[this.blocks%this.nativeBytes]=this.blocks&255;
      if(this.allocRetention!=='transient')this.allocationControl[(this.allocationCursor++)%this.allocationControl.length]=buffer;
    }
    if(this.targetBlocks&&this.blocks===this.targetBlocks){this.go=0;this.port.postMessage({type:'completed'});}
    return true;
  }
  copyProbe(readWords=true) {
    const count=this.exports.probe_word_count();if(!count)return;
    if(count>this.slotWords){this.missedSlots++;return;}
    let chosen=-1;
    for(let n=0;n<this.slotCount;n++){
      const idx=(this.writeCursor+n)%this.slotCount,state=Atomics.load(this.states,idx);
      if((state===0||state===2)&&Atomics.compareExchange(this.states,idx,state,1)===state){
        chosen=idx;if(state===2)this.evictions++;break;
      }
    }
    if(chosen<0){this.missedSlots++;return;}
    const base=chosen*this.slotWords;for(let i=0;i<count;i++)this.payload[base+i]=readWords?this.exports.probe_word(i):0;
    this.lengths[chosen]=count;this.writeCursor=(chosen+1)%this.slotCount;Atomics.store(this.states,chosen,2);
  }
}
registerProcessor('real-onset',RealOnsetProcessor);
