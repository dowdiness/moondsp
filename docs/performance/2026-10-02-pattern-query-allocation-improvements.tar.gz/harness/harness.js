// Browser API: await runScenario({variant:'on', durationMs:2000, warmupMs:300}).
// Constants: 48 kHz, 128-frame quantum, four 16,384-word SAB slots; measurement only uses page clock.
const SLOT_COUNT=4,SLOT_WORDS=16384,RATE=48000;
const SOURCE='let motif = note("60 64 67"); let phrase = stack(motif, motif.slow(2)); stack(phrase, phrase.slow(3), chord("C4 E4 G4"))';
async function makeWire(source=SOURCE){
  const r=await fetch('./authoring.js');if(!r.ok)throw new Error(`authoring.js: ${r.status}`);
  const src=await r.text(),mod=await import(`data:text/javascript;base64,${btoa(unescape(encodeURIComponent(src)))}`);
  const draft=await new Promise((resolve,reject)=>mod.create_draft(source,resolve,reject));
  try{const p=JSON.parse(mod.prepare_playback(draft));if(!p.ok)throw new Error(p.message);return p.input;}finally{mod.dispose_draft(draft);}
}
function parseRecords(a){const records=[];for(let i=0;i<a.length;){const n=a[i];if(n<9||i+n>a.length)throw new Error(`Bad probe record at ${i}: ${n}`);const u=(l,h)=>(BigInt(a[l]>>>0)|(BigInt(a[h]>>>0)<<32n)).toString(),c=a[i+8],bindings=[];if(n!==9+c*12)throw new Error(`Bad binding count ${c}/${n}`);for(let b=0;b<c;b++){const p=i+9+b*12;bindings.push({binding:[u(p,p+1),u(p+2,p+3)],reference:[u(p+4,p+5),u(p+6,p+7)],definition:[u(p+8,p+9),u(p+10,p+11)]});}records.push({runId:a[i+1],sample:u(i+2,i+3),atomEpoch:u(i+4,i+5),atomSerial:u(i+6,i+7),bindingCount:c,bindings});i+=n;}return records;}
export async function runScenario({variant='on',wire,binary,durationMs=2000,warmupMs=500,stallMs=0,capacityWords,sampleRate=RATE,renderMode='aggregate',probeMode='copy',allocBytes=0,nativeBytes=0,allocRetention='retained',targetBlocks=600,profileWindow=false}={}){
  if(!['baseline','off','on','overflow','stalledUI'].includes(variant))throw new Error(`Unknown variant: ${variant}`);
  if(!crossOriginIsolated||typeof SharedArrayBuffer==='undefined')throw new Error('Requires isolated localhost origin (COOP/COEP)');
  const tracked=['on','overflow','stalledUI'].includes(variant);wire??=await makeWire();
  capacityWords??=variant==='overflow'?48:65536;
  const wasmName=binary??(variant==='baseline'?'baseline.wasm':'trial.wasm'),module=await WebAssembly.compile(await(await fetch(`./${wasmName}`)).arrayBuffer());
  const sab=new SharedArrayBuffer((SLOT_COUNT*2+SLOT_COUNT*SLOT_WORDS)*4),states=new Int32Array(sab,0,SLOT_COUNT),lengths=new Int32Array(sab,SLOT_COUNT*4,SLOT_COUNT),payload=new Int32Array(sab,SLOT_COUNT*8);
  const context=new AudioContext({sampleRate});let node,readerTimer;const flat=[];let slotsRead=0;
  try{
    await context.audioWorklet.addModule('./real-onset-processor.js');
    node=new AudioWorkletNode(context,'real-onset',{numberOfInputs:0,outputChannelCount:[2],processorOptions:{module,variant:variant==='baseline'?'baseline':tracked?variant:'off',wire,capacity:Math.max(1,Math.min(65536,capacityWords|0)),sab,slotWords:SLOT_WORDS,slotCount:SLOT_COUNT,renderMode,probeMode,allocBytes,nativeBytes,allocRetention}});
    const ready=new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('worklet ready timeout')),10000);node.port.onmessage=e=>{if(e.data.type==='ready'){clearTimeout(t);resolve();}else if(e.data.type==='failure'){clearTimeout(t);reject(new Error(e.data.message));}};});
    const mute=context.createGain();mute.gain.value=0;node.connect(mute).connect(context.destination);await context.resume();await ready;
    let reading=false;const drain=()=>{if(reading)return;reading=true;try{for(let i=0;i<SLOT_COUNT;i++){if(Atomics.compareExchange(states,i,2,3)!==2)continue;const n=lengths[i],base=i*SLOT_WORDS;for(let j=0;j<n;j++)flat.push(payload[base+j]);Atomics.store(states,i,0);slotsRead++;}}finally{reading=false;}};
    const request=type=>new Promise((resolve,reject)=>{const replyType=type==='finish'?'finished':type,t=setTimeout(()=>reject(new Error(`${type} timeout`)),10000),old=node.port.onmessage;node.port.onmessage=e=>{if(e.data.type==='failure'){clearTimeout(t);reject(new Error(e.data.message));}else if(e.data.type===replyType){clearTimeout(t);node.port.onmessage=old;resolve(e.data);}else old?.(e);};node.port.postMessage({type});});
    readerTimer=setInterval(drain,5);
    node.port.postMessage({type:'go'});if(warmupMs>0)await new Promise(r=>setTimeout(r,warmupMs));
    await request('stop');
    // Restart scheduler on the paused thread so every arm renders the same input blocks.
    await request('reset');flat.length=0;slotsRead=0;
    if(profileWindow){window.__profilerStartReady=true;await new Promise(resolve=>{window.__releaseProfilerStart=resolve;});}
    const start=performance.now();
    const completed=new Promise((resolve,reject)=>{const t=setTimeout(()=>reject(new Error('block completion timeout')),20000),old=node.port.onmessage;node.port.onmessage=e=>{if(e.data.type==='completed'){clearTimeout(t);node.port.onmessage=old;resolve();}else old?.(e);};});
    node.port.postMessage({type:'go',blocks:targetBlocks});
    await completed;
    const report=await request('finish');clearInterval(readerTimer);drain();
    if(profileWindow){window.__profilerStopReady=true;await new Promise(resolve=>{window.__releaseProfilerStop=resolve;});}
    return{variant,probeMode,allocBytes,allocRetention,targetBlocks,wasm:wasmName,sampleRate:context.sampleRate,blockSize:128,durationMs,warmupMs,stallMs,
      audio:{blocks:report.blocks,silentBlocks:report.silentBlocks,nonzeroSamples:report.nonzero,checksum:report.sum,energy:report.energy,peak:report.peak},
      allocation:{query:report.queryAlloc,other:report.otherAlloc},
      probe:{dispatch:report.dispatch,retained:report.records,dropped:report.dropped,runId:report.run,probeChecksum:report.probeChecksum,records:probeMode==='copySlots'?[]:parseRecords(flat),transportSlotsRead:slotsRead,transportSlotsSkipped:report.missedSlots,transportEvictions:report.evictions},
      timing:{clock:'page performance.now only; fixed Worklet render blocks',windowMs:performance.now()-start,workletFrame:report.clockFrame,maxObservedFrameStep:report.maxClockStep},
      conditions:{crossOriginIsolated,userAgent:navigator.userAgent,pcmCapture:'AudioWorklet scalar checksum/energy; Node CLI verifies exact PCM samples'}};
  }finally{clearInterval(readerTimer);node?.disconnect();node?.port.close();await context.close();delete window.__profilerStartReady;delete window.__releaseProfilerStart;delete window.__profilerStopReady;delete window.__releaseProfilerStop;}
}
window.runScenario=runScenario;window.makeTrackedWire=makeWire;
document.querySelector('#status').textContent='ready: runScenario({variant, wire, durationMs, warmupMs, stallMs, capacityWords})';
