import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
const root=new URL('.',import.meta.url),before=JSON.parse(await readFile(new URL('current-before-results.json',root),'utf8')),after=JSON.parse(await readFile(new URL('current-after-results.json',root),'utf8')),rows=[];
assert.equal(before.scenarios.length,after.scenarios.length);
for(let i=0;i<before.scenarios.length;i++){
  const a=before.scenarios[i],b=after.scenarios[i];assert.equal(a.name,b.name);assert.deepEqual(a.states,b.states,a.name+' state');
  assert.deepEqual(await readFile(new URL(`current-before-${a.name}.pcm`,root)),await readFile(new URL(`current-after-${b.name}.pcm`,root)),a.name+' PCM');
  assert(b.total<a.total,a.name+' construction count did not improve');
  rows.push({name:a.name,blocks:a.blocks,before:a.total,after:b.total,reductionFraction:1-b.total/a.total,pcmSha256:a.pcmSha256,pcmAndStatesEqual:true});
}
await writeFile(new URL('render-comparison.json',root),JSON.stringify(rows,null,2));console.log(rows);
