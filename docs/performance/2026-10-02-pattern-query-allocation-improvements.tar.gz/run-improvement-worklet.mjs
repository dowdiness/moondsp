import {readFile,writeFile} from 'node:fs/promises';
import assert from 'node:assert/strict';
import {trackScenario} from './track-worklet.mjs';
import {decodeTracking} from './decode-tracking.mjs';
export async function runWorkletComparison(page,browser,root){
  const wire=JSON.parse(await readFile(root+'/profile-wires.json','utf8')).dense,rows=[];
  for(let round=0;round<2;round++)for(const arm of round?['after','before']:['before','after']){
    const id=`improvement-${round}-${arm}`;
    await trackScenario(page,browser,root,id,{variant:'baseline',binary:`current-${arm}.wasm`,wire,renderMode:'aggregate',probeMode:'none',targetBlocks:600,warmupMs:650});
    const trace=await decodeTracking(root,id),raw=JSON.parse(await readFile(root+'/tracking-'+id+'.json','utf8'));
    rows.push({round,arm,...trace,audio:raw.audio,timing:raw.timing});
    await writeFile(root+'/worklet-improvement.json',JSON.stringify({browser:await browser.version(),rows},null,2));
  }
  for(const row of rows)assert.deepEqual(row.audio,rows[0].audio,'Worklet audio aggregate changed');
  return rows.map(({functions,...row})=>({...row,wasmStack: functions['(root) > process > js-to-wasm::i']}));
}
