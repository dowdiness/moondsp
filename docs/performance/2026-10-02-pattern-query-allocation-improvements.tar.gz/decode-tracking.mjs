import {readFile} from 'node:fs/promises';
import {gunzipSync} from 'node:zlib';
export async function decodeTracking(root,id){
  const meta=JSON.parse(await readFile(`${root}/tracking-${id}.json`,'utf8'));
  const snapshot=JSON.parse(gunzipSync(await readFile(`${root}/tracking-${id}.snapshot.json.gz`)));
  const fields=snapshot.snapshot.meta.trace_function_info_fields;
  if(fields.join(',')!=='function_id,name,script_name,script_id,line,column')throw Error('Unexpected trace-function schema');
  const infos=[];for(let i=0;i<snapshot.trace_function_infos.length;i+=fields.length){let f=snapshot.trace_function_infos.slice(i,i+fields.length);infos.push({name:snapshot.strings[f[1]],script:snapshot.strings[f[2]],line:f[4]});}
  const grouped=new Map();
  function walk(nodes,path){for(let i=0;i<nodes.length;i+=5){const [id,index,count,size,children]=nodes.slice(i,i+5),frame=infos[index],key=[...path,frame.name].join(' > ');let row=grouped.get(key)??{count:0,size:0,script:frame.script,line:frame.line};row.count+=count;row.size+=size;grouped.set(key,row);walk(children,[...path,frame.name]);}}
  walk(snapshot.trace_tree,[]);
  return {id,blocks:meta.blocks,dispatch:meta.dispatch,checksum:meta.checksum,statsEvents:meta.stats.length,seenFirst:meta.seen[0]?.lastSeenObjectId,seenLast:meta.seen.at(-1)?.lastSeenObjectId,functions:Object.fromEntries(grouped)};
}
