#!/usr/bin/env python3
"""Count executed GC constructor instructions per existing Wasm function/op/type.
Diagnostic only: scalar globals; counters are not V8 physical heap allocations.
"""
import json,pathlib,sys,collections
from instrument_alloc import parse,walk,Node
text=pathlib.Path(sys.argv[1]).read_text();module=parse(text)[0]
ops={'struct.new','struct.new_default','array.new','array.new_default','array.new_fixed','array.new_data','array.new_elem'}
insert=collections.defaultdict(list);groups={};meta=[];extra=[]
for fn in module.items:
 if not isinstance(fn,Node) or fn.head!='func':continue
 for node in walk(fn):
  if node.head not in ops:continue
  typ=node.items[1];key=(fn.items[1],node.head,typ)
  if key not in groups:
   i=len(groups);groups[key]=i
   meta.append({'index':i,'function':fn.items[1],'opcode':node.head,'type':typ,'sites':[]})
   extra.extend([f'(global $__fc{i} (mut i64) (i64.const 0))',f'(func (export "__fc_{i}") (result f64) (f64.convert_i64_u (global.get $__fc{i})))'])
  i=groups[key];meta[i]['sites'].append({'line':text.count('\n',0,node.start)+1,'offset':node.start})
  result=f'(exact {typ})' if node.head.startswith('struct.new') else typ
  insert[node.start].append(f'(block (result (ref {result})) (global.set $__fc{i} (i64.add (global.get $__fc{i}) (i64.const 1))) ')
  insert[node.end].insert(0,')')
insert[module.end-1].append('\n'+'\n'.join(extra)+'\n')
result=[];last=0
for pos in sorted(insert):result.extend([text[last:pos],''.join(insert[pos])]);last=pos
result.append(text[last:]);pathlib.Path(sys.argv[2]).write_text(''.join(result))
pathlib.Path(sys.argv[2]+'.json').write_text(json.dumps(meta,indent=2))
print(json.dumps({'groups':len(meta),'sites':sum(len(x['sites']) for x in meta)}))
