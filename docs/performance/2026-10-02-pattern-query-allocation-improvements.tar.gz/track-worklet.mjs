import {writeFile} from 'node:fs/promises';
import {gzipSync} from 'node:zlib';
export async function trackScenario(page,browser,root,id,options){
  const previous=new Set(browser.targets());
  const running=page.evaluate(options=>window.runScenario({...options,profileWindow:true}),options);
  let session,started=false,reported=false;
  try {
    await page.waitForFunction(()=>window.__profilerStartReady===true,{timeout:12000});
    const targets=browser.targets().filter(t=>!previous.has(t)&&t.type()==='other'&&t.url()===new URL(page.url()).origin+'/');
    if(targets.length!==1)throw new Error(`Expected one Worklet, got ${targets.length}`);
    session=await targets[0].createCDPSession();
    const stats=[],seen=[],chunks=[];
    session.on('HeapProfiler.heapStatsUpdate',x=>stats.push(x.statsUpdate));
    session.on('HeapProfiler.lastSeenObjectId',x=>seen.push(x));
    session.on('HeapProfiler.addHeapSnapshotChunk',x=>chunks.push(x.chunk));
    await session.send('HeapProfiler.enable');
    await session.send('HeapProfiler.startTrackingHeapObjects',{trackAllocations:true});started=true;
    await page.evaluate(()=>window.__releaseProfilerStart());
    await page.waitForFunction(()=>window.__profilerStopReady===true,{timeout:30000});
    await session.send('HeapProfiler.stopTrackingHeapObjects',{reportProgress:false});started=false;
    await page.evaluate(()=>window.__releaseProfilerStop());
    const result=await running;reported=true;
    const snapshot=JSON.parse(chunks.join(''));
    await writeFile(root+'/tracking-'+id+'.snapshot.json.gz',gzipSync(chunks.join('')));
    const output={id,options,audio:result.audio,timing:result.timing,conditions:result.conditions,blocks:result.audio.blocks,dispatch:result.probe.dispatch,checksum:result.audio.checksum,stats,seen,snapshotChunks:chunks.length,snapshotBytes:chunks.reduce((s,x)=>s+x.length,0),traceTree:snapshot.trace_tree,traceFunctions:snapshot.trace_function_infos,meta:snapshot.snapshot.meta};
    await writeFile(root+'/tracking-'+id+'.json',JSON.stringify(output,null,2));
    return {id,blocks:output.blocks,dispatch:output.dispatch,checksum:output.checksum,statsEvents:stats.length,seenEvents:seen.length,seenFirst:seen[0],seenLast:seen.at(-1),snapshotChunks:chunks.length,snapshotBytes:output.snapshotBytes,traceTree:snapshot.trace_tree?.slice(0,8),traceFunctionsLength:snapshot.trace_function_infos?.length,meta:output.meta};
  }finally{
    if(started)await session.send('HeapProfiler.stopTrackingHeapObjects',{reportProgress:false}).catch(()=>{});
    if(session)await session.detach().catch(()=>{});
    if(!reported){await page.evaluate(()=>{window.__releaseProfilerStart?.();window.__releaseProfilerStop?.();}).catch(()=>{});await running.catch(()=>{});}
  }
}
