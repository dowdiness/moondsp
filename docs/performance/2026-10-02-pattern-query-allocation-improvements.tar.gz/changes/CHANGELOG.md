# Changelog

All notable changes to this project are documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

### Added

- Added live playback status separating the runtime transport, current Draft
  submission/acceptance, and pending musical-material transitions. Browser
  `player_mode` and `scheduler_cycle_position` expose primitive status on JS and
  wasm-gc without route handles. Musical position follows the piecewise clock
  across tempo changes, freezes while paused, and retains the completed run's
  endpoint after an Ended source update. Reordered receipts cannot roll back
  accepted source versions or overwrite a newer rejection.
  Status receipts now require `mode` and `cyclePosition`; deploy the UI, Worklet,
  and WASM together.
- Published the `PlaybackMode` value enum through the browser facade.
  MoonBit `player_mode()` now returns that enum instead of `Int`; compiled
  JS/wasm-gc mode codes remain `0`/`1`/`2`. Worklet status and receipts now carry
  string-valued `state` and `mode`; UI decoders reject legacy numeric messages.
  The browser policy permits reviewed semantic value types while keeping mutable
  route, pool, and scheduler state private.
  `browser` is now an export library with a facade-owned enum, allowing external
  MoonBit consumers to match its constructors without private imports.
- Simplified live status into playback information and actionable edit feedback.
  Pending parts remain explicit; internal version IDs and material counters move
  behind Technical details. Narrow screens retain usable editor space when the
  disclosure is expanded.
- Added origin-preserving pattern snapshots with checked epoch-qualified source
  IDs, explicit atom and resolved-reference constructors, immutable event origins,
  and exact-preserving control routing. General and exact document lowering now
  share the `Pat` kernels instead of separate provenance time calculations.
  Missing atom/reference attribution fails during exact lowering; voice scopes,
  material keys, periods, musical content policy, and random seeds are retained.
  This adds the compiler API, not editor highlighting or playback telemetry.
- Added `mini.Draft` with versioned atomic UTF-16 edit transactions, checked
  source lifetimes, partial atom/reference recognition through invalid drafts,
  and complete-path `locate_origin`. Same-text replacement, deletion/recreation,
  and broken-then-restored bindings never revive old identities. A missing
  declaration terminator makes later reference bindings unavailable when it
  hides another declaration, even beyond the partial parser's depth limit.
- Added immutable `PlaybackInput` and `PreparedPlayback`: tracked patterns
  compile with exact origins; songs and explicit text inputs retain runtime-only
  capability. Source tracking is bounded to 8192 UTF-16 code units and current
  live facts, without per-spelling lifetime history.
- Connected the live editor's persistent Draft to immutable playback submissions.
  Schema-1 wire validation checks complete source witnesses before admission;
  malformed tracked inputs never fall back to untracked text. Receipts echo the
  submitted draft version, and stale replies cannot overwrite newer diagnostics.
  Automatic updates keep one request in flight and only the latest unsent input;
  manual Update/Restart remain immediate. Exact origins survive scheduler
  material transitions. Playback observations and highlighting remain separate.
- Added exact `Tempo::span_for_samples` conversion through the scheduler clock;
  browser repeat admission no longer reconstructs tempo arithmetic.
- Added the opt-in `@moondsp/browser/audio` entry point with `AudioPower`,
  `PoweredAudio`, and typed setup/end results. MoonBit owns gesture-time
  admission, cancellation, retained cleanup, processor failure observation,
  and replacement ordering; the root `GraphEngine` API remains caller-owned.
  The browser tarball includes the generated JS-target ownership core.
  Generation tasks use MoonBit structured concurrency and typed internal
  completions; JS promises remain at public/browser boundaries. Native error
  identity and cause are preserved across realms, including iframe errors.

- Added explicit Mini `.lpf(hz, resonance?)` and `.hpf(hz, resonance?)`
  controls and connected them, together with `.gain(n)`, to browser note and
  chord voices. Each filter accepts an optional independent resonance/Q value;
  omitting it keeps the `0.707` template default. Low-pass and high-pass filters
  run before the envelope so release completion still reaches exact silence;
  drum templates retain their authored level and filter shape.

- Added retained browser `EngineExit` results and independently cancellable
  `engine.wait({ signal })` observers. Fatal processor errors notify observers
  without another command; normal shutdown and cleanup cannot erase an earlier
  failure. Close acknowledgement has a configurable 5000ms default deadline
  with forced local release on timeout.
- Added the separate JS-target MoonBit `dowdiness/moondsp-browser-host` module,
  pinned to `async@0.21.3`, with `EngineLifetime`, cancellable waits, protected
  close results, and native error/cause identity preservation. DSP/Wasm imports
  and render callbacks are unchanged. Browser tests exercise real Worklet
  lifetime, cancellation, structured errors, and task-group cleanup ordering.
- Added `~` rests to quoted sound, note, and chord notation, plus `.gate(n)`
  for tempo-relative note lengths from 0 through 1 without moving onsets.
- Added live Examples for an overlay groove and a 20-second grouping comparison,
  demonstrating `+` layers and parenthesized transforms with playable Mini scores.
- Added `examples/basic-synth`, with a framework-independent core plus vanilla
  TypeScript and Svelte 5/Vite UI adapters for the same monophonic C4–C5
  instrument. It provides volume and low-pass cutoff controls, release tails, a
  single Power on / Power off control, asset-error recovery, active/held-note
  feedback, bounded keyboard navigation, touch scrolling, and desktop keycaps.
  Both adapters import only the public browser package and use the same shared
  audio owner, graph, keyboard reducer, styles, package lock, and browser
  lifetime scenarios. The Svelte adapter replaces selector configuration and
  manual DOM projection with declarative state, events, and keyed piano markup.
- Added named graph parameters to the browser facade: descriptions can declare
  finite initial values and supported scalar fields can reference them;
  `MountedGraph.setParams()` updates shared targets atomically. Both synth
  adapters use named `volume` and `cutoff` updates while retaining raw atomic note
  frequency/gate batches.
- Added `npm run pack:browser` to build a local `@moondsp/browser` tarball
  containing matching JS, TypeScript declarations, Worklet, Wasm, and license.
  Consumers can build and deploy either adapter without a MoonBit toolchain.
- Added transactional `MountedGraph::apply_controls` and browser
  `applyControls`, plus ADSR, biquad, and multiply browser node descriptions.
  Invalid batches reject without partial mutation; gate-off releases an
  envelope without pausing its graph.
- Added a host-independent MoonBit `GraphEngine` with typed `MountedGraph`
  capabilities, checked errors, independent engine instances, and mono mixing.
  It consumes canonical `Array[DspNode]` values through the existing compiler.
  The browser graph API and standalone `web/graph-example.html` use this engine
  through a thin WASM adapter; graph decoding and lifecycle policy live in MoonBit.
- Added creation-only `AbortSignal` support to the external graph engine.
  Cancellation preserves the caller's context and reports `ABORTED` with the
  original reason. Late initialization cannot publish an abandoned engine.
  Context closure now settles pending initialization and graph commands, releases
  local resources, and lets an in-flight engine close finish without a reply.
- Added adjacent TypeScript declarations for the public graph engine, including
  readonly graph descriptions, discriminated node variants, lifecycle handles,
  creation options, and structured error codes. Added `npm run typecheck:graph`
  to validate consumer usage and rejected API shapes without changing runtime behavior.

### Changed

- Reduced pattern-query allocation with immutable shared node-path tails,
  compilation-time leaf paths, rational identity fast paths, zero-offset event
  shifts, and reuse of contained time spans. Public interfaces, exact event
  origins, and PCM are unchanged. The measured dense 600-block case executes
  about 33% fewer Wasm GC construction instructions; queries are not yet
  allocation-free. See the [dated evidence](docs/performance/2026-10-02-pattern-query-allocation-improvements.txt).
- Aligned MoonBit sources with compiler warning rules: test package APIs are fully
  qualified, trait-implementation methods use explicit extensions, and unused
  package imports are removed. The browser facade explicitly exposes the
  `PlaybackMode` equality/debug methods; its ABI baseline now records them.
  CI now rejects compiler warnings across all targets before the JS test suite.
- **Breaking:** replaced `MiniAuthoringPipeline` with `mini.Draft`. Use
  `edit(EditTransaction)` or explicit `reset`, not full-text setters or
  separately supplied text/edit spans. The public accepted-document channel,
  reactive recomputation counters, and lowering-cache counters are removed;
  preparation is not playback acceptance. `Draft::new` can raise identity
  exhaustion, and `edit`/`reset` return explicit errors atomically.
- **Breaking:** `PatternDoc::every` and `PatternDoc::jux` now take
  `transform~ : TimeTransform` instead of `f~` pattern callbacks. Raw `Pat`
  callbacks remain supported. Removed `PatternSnapshotEvent::pattern_node`;
  scope consumers use `pattern_node_path()`, while exact source consumers use
  `EventWithOrigin::origin()`.
- Renamed graph lifecycle types to `GraphDocument`, `GraphDocumentError`,
  `AnalyzedGraph`, `Dsp`, and `StereoDsp`, including their hot-swap and topology
  controller wrappers. Removed the obsolete `GraphCompileError::InternalRejected`
  case; compilation now retains checked programs before constructing independent
  runtime instances.

  | Previous type | Replacement |
  |---|---|
  | `GraphTemplateDoc` | `GraphDocument` |
  | `GraphTemplateDocError` | `GraphDocumentError` |
  | `CompiledTemplate` | `AnalyzedGraph` |
  | `CompiledDsp` | `Dsp` |
  | `CompiledStereoDsp` | `StereoDsp` |
  | `CompiledDspHotSwap` | `DspHotSwap` |
  | `CompiledStereoDspHotSwap` | `StereoDspHotSwap` |
  | `CompiledDspTopologyController` | `DspTopologyController` |
  | `CompiledStereoDspTopologyController` | `StereoDspTopologyController` |

- Runtime control batches retain prepared per-node updates and adopt them once.
  `BoundVoicePool::apply_voices_controls_result` replaces the separate voice
  validation operation, preserving all-target atomicity and ordered diagnostics.
- Voice template admission retains its compiled graph for a slot or the next
  note instead of discarding it and compiling again during adoption.
- Consolidated snapshot playback into `PatternScheduler::render_block` for dry
  stereo and `render_block_with_send` for dry stereo plus effect send, backed
  by one block-processing implementation. Removed the pattern/song-specific
  rendering aliases and migrated callers. Preserved the base implementation's
  separate send buffer arguments and removed redundant caller-side route
  clearing. This is an API simplification, not a measured speedup over the base.

- Bounded live Player source admission by text size, syntax depth, Euclidean
  steps, arrangement occurrences, and conservative event/work expansion.
  Admission covers future callback branches and full-cycle sequence queries;
  over-budget edits preserve the accepted song and transport. The shipped
  musical examples remain supported; these limits are not a real-time guarantee.
- Made live audio initialization cancellable, with one five-second deadline
  across resume, WASM loading, compilation, module loading, and readiness.
  Startup Pause and close abort pending work and await partial-resource cleanup;
  late native completions cannot activate an obsolete graph or replace a newer run.
- Migrated both basic-synth adapters to `AudioPower`; their shared core retains
  only UI state, graph commands, settings, and stale-note protection. Package
  lifecycle assertions now live in direct public-API browser tests.

- Both synth adapters observe engine termination, report processor failure
  immediately, and treat caller context closure as normal shutdown. Cleanup
  closes the engine as a whole instead of issuing commands to a potentially dead Worklet.
- Both synth adapters use a discriminated lifecycle state and one resource owner
  across partial initialization, a complete session, and retirement. Commands
  serialize per session; cleanup bypasses pending commands, and stale work
  cannot publish into a replacement session.
- Both synth adapters have one Power on / Power off button, with no separate Start,
  Stop notes, or Retry controls. Power on admits audio in the user gesture and
  completes suspended mounting and playback automatically. Power off cancels
  startup or releases the active session; automatic note-release safety remains.
- Updated browser documentation with Wasm synchronization in the demo startup
  commands, packed-package reinstall steps, JS-host lifetime navigation, and
  the public `EngineExit` and `GraphEngineWaitOptions` types. README performance
  claims now distinguish measured sine-kernel allocation removal from
  whole-audio-thread and hard-real-time guarantees.

- Named the asynchronous JavaScript/TypeScript engine factory `GraphEngine`,
  matching the MoonBit public type. Call it as `await GraphEngine({ context })`;
  the same import also names the returned engine's TypeScript type.

- Changed the external graph lifecycle to `engine.mount(graph)`,
  mounted-graph `play()` / `pause()` / `unmount()`, and `engine.close()`,
  without legacy aliases. Concurrent and repeated unmount calls share a
  result; unmounting rejects playback immediately. The browser adapter's
  builder ABI is replaced with JSON input/error transport and explicit engine
  initialization/close. The pre-playback-only mounting restriction remains.

- Added native `Pat[A] + Pat[A]` and Mini `+` overlays with transparent grouping
  parentheses and method-chain precedence, including live editor grammar and
  highlighting.
- Normalized raw overlays in the pattern core while preserving event order,
  duplicates, and opaque transform queries. Separated content identity from
  playback occurrence metadata and authored source ancestry.
- Preserved known material clocks across overlay regrouping while refreshing
  source provenance. Mini references now keep use-site identity across
  definition edits; document reuse checks input revisions instead of assuming
  stable IDs imply unchanged content.
- Resolved Mini references retain declaration witnesses (compiled bodies and
  binding-name spans), preserving strict declaration validation and diagnostic
  precedence while exact lowering checks source binding endpoints.
- Documented the dedicated live scheduler and compiled/demo worklet roles,
  asset synchronization, and separate automated-rendering/listening workflows.
  Live Playwright tests can opt into Chromium virtual audio output with
  `MOONDSP_VIRTUAL_AUDIO=1`; default device selection and runtime ABI are unchanged.
- Updated `dowdiness/incr` from `0.9.0` to `0.15.1`. Mini authoring now uses
  explicit Draft transactions instead of reactive text backdating; the
  incremental value-trait integration remains in `pattern`.
- Updated `PatternDoc`'s incr integration to use the closed monotonic
  `Revision` API while preserving full identity-revision comparison for
  backdating and fingerprint-collision safety.
- Simplified playback internals with source-bound materials, explicit waiting
  and transition states, and shared raw/sourced entry traversal. Public
  interfaces, reserved replacement timing, and event output are unchanged.
- Redesigned live editor playback around parsed tempo/source/request values,
  a closed lifecycle state union, and scheduler/compiled session capabilities.
  DOM callbacks submit intent and render a projection; one wire decoder reports
  malformed messages explicitly. Stop/Retry invalidate retired-session replies.
- Named live audio session operations explicitly: `openSession`, `submitScore`,
  `requestTempoChange`, and `fadeIn`. `SessionCommandResult` distinguishes
  `issued` from `session-expired`; issuing a command does not acknowledge DSP
  acceptance. Session opening and closing return `OpenSessionResult` and
  `CloseSessionResult`.
- Changed `set_scheduler_bpm` to return success/rejection status and added
  `scheduler_bpm` for authoritative effective tempo. Worklet tempo commands now
  require a revision and return correlated success/error acknowledgements;
  score receipts include effective tempo and the processed tempo revision.
  MoonBit rendering and next-entry timing remain unchanged.
- Application admission now returns `2` when starting/restarting is required,
  distinct from ordinary rejection (`1`). Playback error receipts carry
  structured `recovery`; editor behavior no longer depends on diagnostic wording.
  The nonediting tempo field state is named `displaying`, not `synced`.

### Removed

- Removed the ambiguous Mini `.cutoff(hz)` method and pattern `s_cutoff`
  constructor. Use `.lpf(hz, resonance?)` / `s_lpf` for low-pass control or
  `.hpf(hz, resonance?)` / `s_hpf` for high-pass control.

### Fixed

- Prepared exact event origins during pattern compilation instead of extending
  them in reference query callbacks. Context-aware cache reuse preserves
  distinct reference uses and retained snapshots without changing public APIs.
  This removes the identified query-time origin allocations, not all rendering
  allocations; cold compilation costs increase for shared reference paths.
  A measured follow-up keeps the first cached variant directly accessible and
  indexes additional contexts, retaining full identity checks on hash collisions.
  Large reference sets prepare faster; small cases can be slightly slower.
- Kept the strict cookbook parser check compatible with MoonBit v0.10.14:
  identity, pattern, song, and Draft types now explicitly expose their
  existing trait methods, and Mini parser tests use qualified package calls.
  Validation still rejects warnings; runtime behavior is unchanged.
- Restored the mono/stereo single-control prepare/commit path without creating
  a one-element batch. The native release probe records 4 allocations per update
  instead of 7, with retained-batch allocation counts unchanged; this is not an
  allocation-free control API claim. See the
  [measurement record](docs/performance/2026-09-20-graph-single-control-allocation.txt).
- Run MoonBit target-matrix tests and boundary checks for pull requests against
  any base branch, including stacked PRs and PR base changes.
- Preserve the browser demo's first DSP telemetry across asynchronous startup:
  initialization silence no longer consumes the first-block report or its
  warmup counters, so legitimate delay startup samples remain observable.
- Fixed topology-crossfade state aliasing: old and replacement graphs now own
  independent oscillator, noise, envelope, filter, and delay histories.
  Replacement envelope/delay settings are retained; delay capacity changes
  and deletion batches retain their existing fresh-state policy.
- Topology edits now carry their old-to-new node correspondence with the result;
  rewiring a gain's signal input preserves its envelope input.
- Kept source lifetimes independent from parsing success: surviving atoms and
  uniquely proven references remain locatable through unrelated syntax errors,
  while retained playback inputs keep their original immutable witnesses.
  Exact and general atom lowering now retain identical material entry keys.
- Reject unterminated Mini block comments without publishing a valid prefix, and
  share comment scanning between parsing and playback admission so `/* // */`
  cannot hide excessive nesting. Bounded recursive descent now checks depth
  before descending as well.
- Route the legacy demo BPM slider through the current Player controller and
  reflect accepted tempo in both its label and range input, including fractional
  source tempos.
- Reject source or accumulated retained material state above 256 entries per
  browser route. All route clocks, deadlines, and reconciled states are checked
  before installation; rejection preserves playback and Restart can recover
  retained capacity. Source counts include future song occurrences.
- Document the removed scheduler validators/snapshot queries and browser
  prepare/apply tokens with explicit migration paths. Add generated admission
  consistency coverage and opt-in actual-AudioWorklet measurements; measured
  owner updates can still exceed one audio quantum.

- Player now rejects repeated arrangements shorter than one audio block at the
  accepted tempo, including source and demo tempo edits, instead of allowing
  unbounded repetition splitting during rendering. Finite song endpoints are
  checked before source publication or transport/voice reset.
- Canceling initial Player startup no longer sends Pause to an Empty song or
  displays a false error. Closing waits for pending initialization and session
  cleanup, and reopening waits for that retirement to complete.

- The live syntax reference is embedded from `docs/mini-notation.md` at build time,
  with automatic reloads during development and stacked syntax/description pairs
  that remain readable in the narrow help sidebar.
- Corrected implicit song placement help to use the latest end of all preceding
  parts, with regression coverage for out-of-order explicit placements.
- Corrected the browser help: gain and cutoff controls are parsed but are not
  connected to the current browser instruments.
- Removed per-sample scratch allocations from Wasm-GC sine oscillators while
  preserving the existing coefficients, floating-point evaluation order, and
  phase-wrap behavior. Public DSP APIs and other target implementations are unchanged.
- Fixed the external graph example getting stuck after unmount failure. Cleanup
  now attempts each resource independently, preserves the original error, and
  restores the controls so another graph can be mounted.
- Added public graph API type checking to browser CI after the existing
  web/live dependency installation.

- Unified external graph-engine error precedence: closing/closed engines and
  closed contexts reject new requests with `ENGINE_CLOSED`, even after playback.
  Native initialization failures now use `INITIALIZATION_FAILED` and preserve
  the original exception as `cause`. Added browser regressions for these errors,
  pause/resume phase preservation, and immediate rejection during unmount.

- Made concurrent browser graph-engine close calls share one completion promise,
  preventing spurious `ENGINE_CLOSED` rejections and closing admission as soon
  as shutdown starts.

- Fixed overlay content comparison depending on subgroup names, nested material
  boundaries, or named silence. Content normalization is now independent of
  playback scopes, without flattening opaque queries or removing playback
  placeholders.
- Preserved uncommitted live-editor BPM input across unrelated playback replies,
  while retaining normalization on Enter or blur.
- Prevented stale tempo acknowledgements from undoing newer edits. Runtime
  rounding and song tempo below the manual input minimum are reflected in the
  editor; contextual tempo rejection restores the effective BPM and reports
  the error without stopping playback.
- Kept graph failure handling active through Stop, suspension, and resume.
  Faulty graphs are discarded, interrupted opens complete with failure, and
  delayed close/resume completions cannot overwrite failure or Retry.
  Retired audio session commands now return `session-expired` without changing output
  or posting commands to a later playback run.
- Fixed authored Euclid playback dropping notes from stacked child patterns.
  Its sourced query now follows the single canonical Euclid entry while
  preserving every child's note timing and authored path.

## [0.6.0] - 2026-09-12

This release advances moondsp from its browser audio proof into a live
pattern-and-song authoring environment, adds the native CLAP prototype, and
hardens the graph, scheduler, browser, and incremental-authoring boundaries.

### Breaking changes

- Consolidated the Mini `PatternDoc` reuse helpers into optional arguments:
  replace `parse_doc_reusing(input, previous)` with
  `parse_doc(input, previous=Some(previous))`, and replace
  `parse_snapshot_reusing(input, previous)` with
  `parse_snapshot(input, previous=Some(previous))`.
- Replaced the browser eval/parse-and-set/update playback entry points and
  separate pattern/song input and error buffers with a shared input buffer,
  token-returning `prepare_pattern_input` / `prepare_song_input`,
  `apply_prepared_playback`, `discard_prepared_playback`, and
  `restart_playback`. Worklet hosts now use `apply-score` with an explicit
  continue/restart policy or `restart-playback`; no compatibility aliases
  remain.
- Removed the legacy browser facade route shell types `SoundPool`,
  `SchedulerRouteSelector`, and `SchedulerRoute`. Runtime routing remains
  behind the browser worklet exports.
- Removed the graph package's accidental DSP facade re-exports. Import DSP
  types, traits, and helpers from `dowdiness/moondsp/dsp` or the root
  `dowdiness/moondsp` facade instead of `dowdiness/moondsp/graph`.
- Replaced scheduler `AffectedVoiceTarget`, `AffectedVoicePolicy`, and
  `AffectedVoiceEditScope` with separate `PatternVoiceScope` /
  `SongVoiceScope` selectors and explicit `ActiveVoiceEffect` operations.
  Retune now requires a non-empty `VoiceControlBatch`; preserve behavior is
  snapshot queuing without an active-voice effect.
- Renamed scheduler `PlaybackEditOutcome` to `ActiveVoiceEffectOutcome`,
  `controlled_voice_count` to `retuned_voice_count`, and
  `removed_active_note_count` to `detached_note_count`. Detachment counts
  scheduler note records, not destroyed pool voices; Release tails may continue
  sounding. Effect behavior is unchanged; no compatibility aliases remain.

### Added

- Added browser live song playback with explicit Pattern/Song modes, global
  BPM handling, multiline song authoring, inline parse diagnostics, and
  last-good playback on invalid edits.
- Added immutable named pattern definitions with `let name = expression;` for
  reuse from both pattern and song inputs. Name resolution preserves authoring
  structure, event provenance, and dependency-aware lowering-cache reuse.
- Added prepared live edits that preserve playback position by default, apply
  changed material at its next entry, acknowledge success after the committed
  block renders, and provide an explicit restart path.
- Added independent synth-note envelopes, expanded musical examples, and a
  shared stereo room-reverb bus across synth and drum routes.
- Added Strudel-style `$:` stack lines, note-name and chord parsing, and editor
  highlighting, completion, and help for the new Mini notation.
- Added `MiniAuthoringPipeline`, an `incr`-backed text → `PatternDoc` →
  snapshot pipeline with stable token and node identities, persistent lowering
  reuse, source-edit-span realignment, compute diagnostics, and an
  `AcceptedDerived` last-good document channel across parse failures.
- Added `MiniDocBuilder` as the semantic `PatternDoc` construction surface used
  by Loom/CST evaluation, plus ADRs and parity evidence for a future
  production authoring-parser decision. The shipping authoring path remains
  whole-source `MiniAuthoringPipeline`.
- Added structural equality for `DspNode` and `CompiledTemplate`, result-typed
  `CompiledDsp::compile_result` / `CompiledStereoDsp::compile_result`
  diagnostics, and documented external DSL lowering and editor-preview
  boundaries.
- Added typed voice mutation APIs:
  `VoicePool::note_off_result`, `VoicePool::set_voice_pan_result`,
  `BoundVoicePool::note_off_result`, `BoundVoicePool::kill_result`, and
  `BoundVoicePool::set_voice_pan_result`.
- Added browser facade/worklet ABI documentation, generated ABI baseline
  checks, and stable parse/control result-code and error-message transport.
- Added a native CLAP synth prototype with official CLAP 1.2.8 headers, Linux
  and Windows builds, validator and dlopen/process smoke tests, a generated
  MoonBit bridge-symbol guard, timestamped note/parameter processing, and a
  verified Bitwig Studio 6.0.6 load on Windows 11. CLAP support remains
  prototype-only pending broader real-host coverage.

### Changed

- Migrated the root manifest from `moon.mod.json` to `moon.mod`, updated
  `moonbitlang/quickcheck` to `0.14.0`, and advanced `dowdiness/incr` to
  `0.9.0`.
- Extracted graph, scheduler, and browser implementation packages behind their
  existing facades. The canonical graph boundary remains
  `Array[DspNode]` → `CompiledTemplate::analyze` → runtime compilation.
- Tightened browser playback-host helper exposure so package-local probes no
  longer leak host-owned pools, schedulers, or buffers.
- Simplified the live editor to one Play/Stop transport and moved complete,
  playable examples ahead of concise reference help.
- Unified scheduler provenance and edit execution around typed voice origins.
  Pattern origins carry a non-empty authored path; song origins carry
  occurrence, section, and layer identity. Snapshot effect calls preflight all
  retunes and queue replacement only after the effect succeeds.

### Deprecated

- Deprecated the Bool-returning voice-control compatibility wrappers
  `VoicePool::note_off`, `VoicePool::set_voice_pan`,
  `BoundVoicePool::note_off`, `BoundVoicePool::kill`, and
  `BoundVoicePool::set_voice_pan`. Use the corresponding `*_result` methods to
  preserve `VoiceControlError` rejection details.

### Fixed

- Stabilized browser synth playback and added page-thread/AudioWorklet
  comparison probes for scheduler, voice-pool, and waveform paths. Production
  playback retains the Triangle fallback while issue #212's affected-Windows
  real-time A/B investigation remains open.
- Preserved current playback through valid live score edits and invalid
  intermediate text instead of implicitly restarting or tearing down audio.
- Preserved runtime-updatable `Gain` and `Clip` nodes through constant folding
  so authoring-index controls and bindings retain their parameter semantics
  while pure arithmetic subgraphs can still fold.

### Performance

- Added cross-target external-authoring benchmarks and dated snapshots for
  valid, diagnostic, and realistic graph shapes; the measurements did not
  justify an early-cutoff optimization.
- Measured AudioWorklet preparation separately from render-quantum processing
  and kept parsing, projection, and snapshot preparation outside the audio
  callback.
- Eliminated audited allocations from steady CLAP render, note/release, MIDI,
  transport, all-notes-off, and active-parameter event paths.

## [0.5.1] - 2026-05-20

### Added

- Mini notation now accepts `.cutoff(f)` method chains such as
  `s("bd").cutoff(200)`, lowering through the existing `ControlMap` and
  `merge_control` path in both runtime parsing and PatternDoc parsing.
- Mini notation now accepts `.gain(g)` and `.pan(p)` method chains with the
  same runtime and PatternDoc lowering path as `.cutoff(f)`.

## [0.5.0] - 2026-05-20

### Breaking changes

- **`AudioBuffer::as_fixed_array` has been removed.** The method exposed
  the buffer's internal storage directly, letting callers bypass the
  `AudioBuffer` write methods and any validation attached to them.

  **Migration:** use `AudioBuffer::all` / `AudioBuffer::any` for
  predicate-style scans, or use `length` + `get` for indexed reads.
  Use `AudioBuffer::adopt` only when an explicit zero-copy shared-storage
  contract is required.

- **`AudioBuffer::new` (and `AudioBuffer::AudioBuffer`) now defensively
  copies its argument.** Previously, the constructor stored the caller's
  `FixedArray` by reference, so the buffer and the source array shared
  storage in both directions: writes to the source appeared in the
  buffer, and writes through `AudioBuffer::set` / `AudioBuffer::fill`
  mutated the source. Both directions are now decoupled.

  **Migration:** callers that depended on the shared-storage behavior
  should replace `AudioBuffer::new(arr)` with `AudioBuffer::adopt(arr)`.
  See the constructor docstrings in `dsp/buffer.mbt` for the full
  contract on both forms.

- **`AudioBuffer` now normalizes non-finite samples on MoonBit-owned
  writes.** Values written through `AudioBuffer::new`, `AudioBuffer::filled`,
  `AudioBuffer::fill`, and `AudioBuffer::set` convert `NaN`, `+Inf`, and
  `-Inf` to `0.0`; finite values, including values outside `[-1, 1]`, pass
  through unchanged. `AudioBuffer::adopt` remains the explicit zero-copy
  bypass for retained source-handle mutation, though writes through
  `buf.set(...)` and `buf.fill(...)` on an adopted buffer still normalize.

### Added

- `AudioBuffer::all((Double) -> Bool raise?) -> Bool raise?` and
  `AudioBuffer::any((Double) -> Bool raise?) -> Bool raise?` — predicate
  scans over buffer samples with `raise?` parity to the underlying
  collection helpers.

- `AudioBuffer::adopt(FixedArray[Double]) -> AudioBuffer` — explicit
  zero-copy adoption for FFI / SharedArrayBuffer–style buffer bridging.
  The buffer and the source array share storage; mutations through the
  retained source handle bypass any future write-time validation by
  design.

## [0.4.0] - 2026-05-18

This release bundles two breaking refactors of the graph public API plus
a `dsp` package visibility tightening:

1. **Graph runtime exchange boundary is now `CompiledTemplate`.**
   `Array[DspNode]` remains the *authoring* exchange type; `CompiledTemplate`
   is the *runtime* exchange type, produced by the single canonical crossing
   `CompiledTemplate::analyze`. See
   [ADR-0010](docs/decisions/0010-compiled-template-runtime-boundary.md) for
   the contract and `scripts/check-public-boundary.sh` for enforcement.
2. **Runtime graph control API is now `Result`-typed.** Across all six
   `Compiled*` wrapper types in the graph package and the
   `GraphControllable` trait, every control method (`gate_on`, `gate_off`,
   `set_param`, `apply_control`, `apply_controls`, `queue_swap`,
   `queue_topology_edit`, `queue_topology_edits`) returns
   `Result[Unit, ErrorType]` with a specific rejection reason. The
   `_result` suffix is gone from these graph control methods:
   `apply_control_result` is now `apply_control`, etc. This closes the
   silent-failure footgun class addressed previously by `BoundVoicePool`
   (see
   `docs/superpowers/specs/archive/2026-05-11-bound-voice-pool-design.md`),
   where `ignore(...)` on a Bool control return swallowed the rejection
   reason and let stale-template errors propagate unnoticed. (Note:
   `BoundVoicePool::apply_voice_control_result` / `_controls_result` /
   `validate_voice_controls_result` in the `voice/` package keep their
   suffix; that surface is unchanged by this release and will be
   harmonized in a follow-up.)
3. **`dsp` package visibility tightening.** `EnvStage` enum tightened from
   `pub(all)` to `pub`; `ChannelSpec` trait tightened from `pub(open)` to
   `pub`. External `is EnvStage::X` pattern matching continues to work;
   external variant construction and external `ChannelSpec` impls are
   no longer permitted. See "Breaking changes — `dsp` visibility
   tightening" below. (Also in this release, but non-breaking: a
   per-block-constant hoisting pass on `Adsr::process` and
   `Oscillator::process_waveform` — see "Performance" below.)

### Migration — `CompiledTemplate` boundary

```moonbit
// Before (v0.3.x)
CompiledDsp::compile(nodes, ctx)
CompiledStereoDsp::compile(nodes, ctx)
VoicePool::new(nodes, ctx, max_voices=4)              // -> VoicePool?
VoicePool::set_template(pool, nodes)                  // -> Bool
BoundVoicePool::new(nodes, ctx, builder, max_voices=4)
BoundVoicePool::set_template(pool, nodes, builder)

// After (v0.4.0)
let template = CompiledTemplate::analyze(nodes)
CompiledDsp::compile(template, ctx)
CompiledStereoDsp::compile(template, ctx)
VoicePool::new(template, ctx, max_voices=4)           // -> Result[VoicePool, VoicePoolError]
VoicePool::set_template(pool, template)               // -> Result[Unit, VoicePoolError]
BoundVoicePool::new(template, ctx, builder, max_voices=4)
BoundVoicePool::set_template(pool, template, builder)
```

### Migration — Result-typed control API

```moonbit
// Before (v0.3.x)
let ok = compiled.gate_on(0)                          // -> Bool
let ok = compiled.set_param(1, GraphParamSlot::Value0, 0.5)  // -> Bool
let ok = compiled.apply_control(GraphControl::gate_on(0))    // -> Bool (via trait)
let ok = hot_swap.queue_swap(replacement)             // -> Bool
let ok = topology.queue_topology_edit(edit)           // -> Bool
// Result-typed peers were spelled with a `_result` suffix:
let r = compiled.gate_on_result(0)                    // -> Result[Unit, GraphControlError]

// After (v0.4.0)
let r = compiled.gate_on(0)                           // -> Result[Unit, GraphControlError]
let r = compiled.set_param(1, GraphParamSlot::Value0, 0.5)   // -> Result[Unit, GraphControlError]
let r = compiled.apply_control(GraphControl::gate_on(0))     // -> Result[Unit, GraphControlError]
let r = hot_swap.queue_swap(replacement)              // -> Result[Unit, HotSwapQueueError]
let r = topology.queue_topology_edit(edit)            // -> Result[Unit, GraphTopologyQueueError]
// The `_result`-suffixed methods are gone. Drop the suffix to get the same behavior.
```

Common assertion-rewrite patterns:

| Before                                              | After                                                        |
| --------------------------------------------------- | ------------------------------------------------------------ |
| `assert_true(x.gate_on(i))`                         | `assert_true(x.gate_on(i) is Ok(_))`                         |
| `assert_false(x.queue_swap(g))`                     | `assert_true(x.queue_swap(g) is Err(_))`                     |
| `if !x.apply_controls(params) { ... }`              | `if x.apply_controls(params) is Err(_) { ... }`              |
| `match x.gate_on_result(i) { ... }`                 | `match x.gate_on(i) { ... }` — drop the `_result` suffix     |
| `ignore(x.gate_on(i))` in production code           | `ignore(x.gate_on(i))` still type-checks, but consider whether swallowing the error is correct; in tests, prefer `is Ok(_)`; in benchmarks where success is required, `.unwrap()` |

### Breaking changes — `CompiledTemplate` boundary

- **`CompiledDsp::compile(Array[DspNode], DspContext)` removed.**
  `compile_template` renamed to `compile(CompiledTemplate, DspContext)`.
  Same for `CompiledStereoDsp`.
- **`VoicePool::new` and `set_template` now take `CompiledTemplate` and
  return `Result[..., VoicePoolError]`.** Variants: `InvalidMaxVoices`,
  `OrphanAdsr`, `CompileRejected`. Mirrors `BoundVoicePoolError` minus
  `Binding(...)`.
- **`BoundVoicePool::new` and `set_template` now take `CompiledTemplate`.**
  Return shape (`Result[..., BoundVoicePoolError]`) unchanged.
- **`optimize_graph` is now package-private.** Use
  `CompiledTemplate::analyze` instead — it runs constant folding and
  dead-node elimination exactly once and produces the runtime boundary
  type in one step. Removed from the root facade re-export list.

### Breaking changes — Result-typed control API

- **Bool-returning control methods deleted on `CompiledDsp` and
  `CompiledStereoDsp`** (`gate_on`, `gate_off`, `set_param`,
  `apply_control`, `apply_controls`). The previously-named `_result` peers
  absorb those names and return `Result[Unit, GraphControlError]`.
- **Bool-returning `queue_swap` deleted on `CompiledDspHotSwap` and
  `CompiledStereoDspHotSwap`.** `queue_swap_result` is renamed
  `queue_swap` and returns `Result[Unit, HotSwapQueueError]`. The other
  control methods (`gate_on`, `gate_off`, `set_param`, `apply_control`,
  `apply_controls`) on these types had no Bool peer — they are renamed
  (suffix dropped) but no API was deleted.
- **Bool-returning `queue_topology_edit` / `queue_topology_edits` deleted
  on `CompiledDspTopologyController` and
  `CompiledStereoDspTopologyController`.** `_result` peers absorb those
  names and return `Result[Unit, GraphTopologyQueueError]`. Other control
  methods are renamed (no Bool peers existed).
- **`GraphControllable` trait now returns `Result[Unit, GraphControlError]`**
  from both `apply_control` and `apply_controls`. The trait was also
  tightened from `pub(open)` to `pub` in this release, sealing it against
  external impls; only the in-package `Compiled*` types implement it, and
  they have been updated.
- **All `*_result`-suffixed public methods on graph `Compiled*` types
  removed** (their behaviour is now the only behaviour, exposed without
  the suffix): `apply_control_result`, `apply_controls_result`,
  `validate_controls_result`, `gate_on_result`, `gate_off_result`,
  `set_param_result`, `queue_swap_result`, `queue_topology_edit_result`,
  `queue_topology_edits_result`. The `voice/` package's
  `BoundVoicePool::apply_voice_control_result` family is *not* part of
  this change and keeps its current names.
- Pure Bool queries on `Compiled*` types — `is_voice_finished` and
  `has_feedback_edges` — are intentionally kept; they are queries, not
  control operations. Other Bool-returning public APIs across the package
  (`node_accepts_slot`, `GraphTemplateDoc::contains_node` / `contains_retired_node`,
  trait methods on `NodeEditable` / `NodeFoldable` / `NodeStateful`,
  the module-level `is_finite`) are unaffected.

### Breaking changes — `dsp` visibility tightening

- **`EnvStage` enum tightened from `pub(all)` to `pub`.** External
  `is EnvStage::X` pattern matching continues to work per MoonBit
  access-control rules (`pub` types remain readable / destructurable from
  outside the package). External *construction* of `EnvStage` variants is
  no longer permitted; downstream code that needs an `EnvStage` value
  should read it from `Adsr::stage(self)`. No call site in the workspace
  constructed `EnvStage` variants externally.
- **`ChannelSpec` trait tightened from `pub(open)` to `pub`.** Only `Mono`
  and `Stereo` implement `ChannelSpec`, both inside `dsp/`. Downstream
  packages can no longer add their own `ChannelSpec` impls. The
  tagless-algebra traits (`ArithSym`, `DspSym`, `FilterSym`, `StereoSym`,
  `DelaySym`, `StereoFilterSym`, `StereoDelaySym`) stay `pub(open)` —
  alternate interpreters like `GraphBuilder` need them.

### Added

- `CompiledTemplate::adsr_authoring_indices(Self) -> FixedArray[Int]` —
  authoring indices of surviving ADSR nodes, used by `voice/` for
  note_on / note_off gating.
- `GraphBuilder::analyze(Self) -> CompiledTemplate` — sugar over
  `CompiledTemplate::analyze(builder.nodes())`.
- `BoundVoicePoolError::from_voice_pool(VoicePoolError) -> Self` —
  remaps a `VoicePoolError` into a `BoundVoicePoolError` for callers
  composing the two error types.
- `VoicePoolError` re-exported through the root `@moondsp` facade so
  consumers can pattern-match `VoicePool::new` Results ergonomically.

### Performance — `dsp` per-block hoisting

- **`Adsr::process` no longer re-validates `sample_rate` per sample.**
  Validation runs once at block entry; a new private `Adsr::tick_step`
  stepper assumes a finite positive `sample_rate` and is called directly
  inside the per-sample loop. The public `Adsr::tick(context)` retains
  its full validation contract for direct callers.
- **`Oscillator::process_waveform` hoists `freq_hz / sample_rate` out of
  the per-sample loop.** A new private
  `Oscillator::tick_step(waveform, phase_increment)` is called inside the
  loop, eliminating both per-sample validation and per-sample division.
  Added a guard on the quotient: the buffer is silenced if
  `phase_increment` is non-finite (e.g. `Double::MAX / Double::MIN_POSITIVE`
  → `Inf`), matching dsp's existing fill-0-on-invalid pattern. The
  block-processing path (`process_waveform`) is now safe against
  pathological quotients that would previously NaN-poison the oscillator
  phase. Direct callers of `tick_waveform` still need to validate the
  quotient themselves; that path is unchanged in this release.
- Replaced the magic literal `6.283185307179586` with `2.0 * @math.PI` in
  `sample_for_phase`, matching the convention in `filter.mbt` and
  `pan.mbt`.

### Carve-outs (NOT migrated — see ADR-0010 § Boundary exceptions)

The following public APIs keep `Array[DspNode]` in their signatures by
design. Each is enforced by an allowlist entry in
`scripts/check-public-boundary.sh`.

- `CompiledTemplate::analyze(Array[DspNode])` — the canonical authoring
  → runtime crossing; the entire migration is built around this entry
  point.
- `replay(Array[DspNode])` — pre-optimize debug / round-trip.
- `CompiledDspTopologyController::from_nodes(Array, ctx, crossfade?)` and
  `CompiledStereoDspTopologyController::from_nodes(...)` — edit-as-you-go
  composites.
- `GraphBuilder::nodes`, `GraphTemplateDoc::nodes` — authoring /
  inspection accessors.
- `GraphTemplateDoc::from_nodes`, `::insert_chain` — authoring artifact
  construction.
- `GraphIndexMap::insert_chain`, `GraphTopologyEdit::InsertChain` (and
  constructor) — authoring payloads.

### Internal

- `voice/` internal storage migrated from `Array[DspNode]` snapshots to
  `FixedArray[Int]` ADSR-authoring-index snapshots. The PR-2 pinning
  tests (`voice/voice_pinning_test.mbt`) pin the public outcome of
  `VoicePool::new` and `set_template` across the migration.
- Added `scripts/check-public-boundary.sh` and
  `.github/workflows/boundary-check.yml` enforcing ADR-0010 carve-outs
  in CI.

## [0.3.1] - 2026-05-17

### Added

- **`PatternScheduler::bpm()` read accessor.** Restores public read access
  to the current tempo after v0.3.0 privatized the `bpm` field. The
  accessor returns the sanitized value (NaN/Inf rejected, clamped to
  ≥1.0 at construction and `set_bpm`). Symmetric with the existing
  `sample_counter()` reader; non-breaking.

## [0.3.0] - 2026-05-16

### Breaking changes

- **`DspNode::delay`, `DspNode::stereo_delay`, `DspNode::envelope_gain` now
  require labelled arguments.** Each of these constructors takes two `Int`
  positions for distinct roles (input source vs delay-buffer capacity;
  input signal vs envelope modulator) where order is silently flippable.
  New signatures (label names match the existing parameter names — no
  rename, no defaults changed):
  - `DspNode::delay(input~, max_delay_samples~, delay_samples?, feedback?)`
  - `DspNode::stereo_delay(input~, max_delay_samples~, delay_samples?, feedback?)`
  - `DspNode::envelope_gain(input~, envelope~, amount~)`
- **`PatternScheduler` struct fields are now private.** The fields `bpm`,
  `sample_counter`, `ctx`, `active_notes`, and `mapper` were exposed as
  public on the struct, allowing external readers (and external writers
  for the `mut` ones) to bypass the scheduler's invariants. They are now
  `priv`. Purpose-built observation remains through methods
  (`sample_counter`, `current_block`, `active_note_count`,
  `active_note_source`, `active_note_matches`); BPM changes go through
  `set_bpm`. Direct reads of `bpm`, `ctx`, `mapper`, and the backing
  `active_notes` array are no longer public API. (A `PatternScheduler::bpm()`
  read accessor lands in v0.3.1.)
- **`NodeSpanning`, `NodeFoldable`, `NodeStateful`, `NodeEditable` traits
  removed from the public `@moondsp` facade.** These are graph-internal
  implementation-detail traits (used to classify `DspNode` variants
  during compile/optimize/edit). They had no documented external
  consumers and the trait surface itself remains usable inside
  `@dowdiness/moondsp/graph` for internal extension.

### Changed

- **Constructors migrated to canonical `Type::Type` form** across the
  codebase (v0.9.2 toolchain alignment; 30 `#alias(new)` shims total,
  of which 21 are public constructor aliases in the generated
  interfaces). Old `Type::new(…)` call sites continue to work via the
  shims — no migration required for consumers, but new code should
  prefer the canonical form (`Adsr::Adsr(...)`,
  `DspContext::DspContext(...)`, `Rational::Rational(...)`, etc.).

## [0.2.0] - 2026-05-16

### Breaking changes

- **`PatternScheduler::new` signature** — the `bindings~ : ControlBindingMap`
  parameter was removed. `BoundVoicePool` now owns the binding map and is
  passed to scheduler block-processing methods in place of the raw
  `VoicePool`. Migrate by constructing a `BoundVoicePool` from your pool
  plus bindings and replacing `pool` arguments to `process_block`,
  `process_events`, and `expire_notes` with the bound pool.
- **Positional-to-labelled DSP/browser helper arguments** — to surface
  ordering mistakes at compile time, the following calls now require
  labelled arguments instead of positional ones: `Oscillator::process`,
  `Oscillator::process_waveform`, `Oscillator::tick`,
  `Oscillator::tick_waveform`, `Gain::process`, `Clip::process`,
  `Pan::process`, `DspNode::stereo_gain`, `DspNode::stereo_clip`,
  `DspNode::stereo_biquad`, `DemoSource::tick_source`, browser `tick`,
  browser `tick_source`, and the matching `browser_test` shims.
- **Public struct field/raw-constructor abstraction** — several DSP/graph
  structs no longer expose raw fields or internal constructors as part of
  the public surface. Affected types include state fields on `Adsr`,
  `AudioBuffer`, `Biquad`, `DelayLine`, `DspContext`, `Noise`,
  `Oscillator`, `ParamSmoother`; dummy unit fields on `Gain`, `Clip`,
  `Mix`, `Pan`; raw `DspNode` and `GraphControl` fields and internal
  constructors; `GraphBuilder` and `ControlBindingBuilder` internals; and
  `PatternScheduler.bindings`. Use the public constructors (`DspNode::adsr`,
  `Gain::new`, etc.) and accessor methods (`DspNode::kind`, `input0`,
  `value0`, …) instead of field access.

### Removed

- **`pattern.ControlMap::inner`** — was marked `#deprecated` in `v0.1.0`;
  use `ControlMap::entries`, `each`, `get`, `set`, `merge`, `single`, or
  `empty` instead.

### Added

- **Mini-notation grammar extensions:**
  - **Top-level `stack(p1, p2, ...)` primitive** (#20) — combine independent
    patterns at the expression level, including cross-source mixes like
    `stack(s("bd sd"), note("60 64"))`. Each argument is a full expression,
    so per-arg method chains and result method chains both work. Closes
    the gap that previously forced layer-stacking inside a single notation
    string (which can't mix `s` and `note`).
  - **Euclidean rhythms** (#15) — `s("bd(3,8)")` and `s("bd(3,8,2)")` for
    pulses, steps, and rotation.
  - **Step operators `*n` / `/n`** (#18) — in-slot replication and stretch
    (`s("bd*4")`, `s("bd/2")`).
  - **`degradeBy(p)` method, `every(n, f)` method, `?` step operator** (#17)
    — probabilistic event drop, periodic transformations, and per-step
    50% drop with deterministic seeding.
  - **`.jux(f)` method** (#19) — Strudel-style stereo split with `f`
    applied to the right channel only.
- **Drum sounds:** `cp` (clap, MIDI 39) and `oh` (open hi-hat, MIDI 46),
  with synthesis templates and per-sound routing (#21).
- **Live-coding REPL** (#12) — `web/live/` Strudel-style editor surface
  with CodeMirror 6, debounced eval, inline parse-error squiggles via
  the canopy adapter, and a "kept last good" recovery model. Includes
  runtime-error teardown coverage (#14), design-system overhaul
  (typography, tokens, motion, a11y), and a mini-notation cheatsheet
  sidebar.
- **Live REPL autocomplete + syntax highlighting** (#23) — context-aware
  completions across four cursor positions: top-level functions
  (`s`, `note`, `stack`), method chain (`.fast` / `.slow` / `.rev` /
  `.degradeBy` / `.every` / `.jux`), drum names inside `s("…")`, and
  callbacks inside `jux(…)` / `every(_, …)`. Backed by a small Lezer
  grammar for the outer surface; the inner mini-notation stays opaque
  to keep the wasm-side parser the single source of truth. Includes
  default syntax highlighting and bracket auto-pairing.
- **Phase 6 identity groundwork** — new dependency-free `identity/` package
  with typed stable IDs, `Revision`, and revision comparison plus ordered
  aggregation helpers; `song/` now supports explicit occurrence IDs, stable-ID
  lookup, and ID-preserving tests across reordering and section length changes.
- **Phase 6 pattern authoring groundwork** — `pattern/` now has an
  identity-bearing authoring document with private node storage, revisioned
  edits, stable node lookup helpers, and lowering back to the existing runtime
  pattern query model. Aggregate pattern documents derive their revision from
  an ordered child-revision mix so changed child content invalidates parent
  snapshots. The authoring layer covers the runtime pattern operations,
  including filtering, Euclidean rhythms, degradation, periodic transforms,
  stereo split, and control-map merging.
- **Phase 6 pattern lowering cache** — lowering reuse keyed by stable node
  identity, a private subtree token, and full revision equality, with
  per-node revision metadata inside authoring storage. Editing one child
  invalidates that child and its ancestors while sibling lowerings are
  reused; divergent edits forked from the same base document do not alias
  cache entries.
- **Phase 6 mini-notation stable-ID reconciliation** (#36) — deterministic
  `PatternNodeId` assignment for parsed mini atoms, combinators, sequences,
  stacks, and method chains. New `parse_doc`, `parse_doc_reusing`,
  `parse_snapshot`, and `parse_snapshot_reusing` entry points expose mini
  output through `PatternDoc` / `PatternSnapshot` while preserving the
  existing `parse` API. `PatternDoc::subdoc` lets reconciliation reuse
  unchanged parsed subtrees so whitespace-only and unaffected-token
  reparses hit the lowering cache.
- **Phase 6 graph identity mapping** (#37) — new `GraphTemplateDoc` owns
  stable `GraphNodeId` authoring IDs, graph nodes, revisions, and a
  retired-ID set; `GraphIndexMap` maps stable IDs to existing graph
  indices and builds existing `GraphControl`, `ControlBindingBuilder`, and
  `GraphTopologyEdit` values at API boundaries. Document edits preserve
  IDs across replacements/rewires, append for inserts, compact for
  deletes, and reject reuse of retired IDs in the same document. The root
  `@moondsp` facade re-exports `GraphNodeId`, `Revision`, and
  `StableIdError` for documented facade consumers.
- **`song/` package — long-form arrangement layer** — new `song/` package
  introduces `Section`, `SectionBody` / `SectionLayer`, `SectionPatch`,
  and `Song` / `SongPart` as the long-form arrangement layer between the
  pattern engine and the scheduler, before the explicit-start ranges and
  identity-bearing authoring docs land in the entries below.
- **Sample-time scheduler note expiry** — scheduler note expiry switched
  from a tick counter to sample time via `PerformanceTime`,
  `cycle_to_sample`, and `expire_notes_at`, so already-active notes keep
  stable gate-off sample times across tempo changes.
- **Phase 6 song authoring** — explicit-start layout ranges with
  gaps/overlaps and `Song::occurrences_at` / `occurrences_intersecting`
  point and range lookup (#38); `Song::gap_spans` plus `Song::fill_gaps`
  for derived boundary fills that preserve existing IDs (#39); song
  mini-notation (`parse_song`, `section`, `part`, `part_id`, `fill`) over
  the existing pattern mini surface (#40); `TimeScope` rate transforms
  (`at_rate`, `fast`, `slow`) routed through both `Song::query` and
  direct section playback (#41); secondary indexes for occurrence name,
  stable ID, start time, and end time, preserving authoring-order overlap
  semantics (#42); identity-preserving section/layer authoring with
  display rename stability and revision boundaries (#43); and an
  identity-preserving song layout authoring model that survives rename,
  insertion, removal, reorder, explicit-start, and section-length edits
  (#44).
- **Phase 6 scheduler snapshot swap and edit orchestration** —
  block-boundary snapshot swap (`PatternScheduler::queue_pattern_snapshot`
  + `process_snapshot_block`) with let-ring across silent replacements
  and coalescing of multiple staged snapshots (#35); shared pattern/song
  snapshot staging with whole-document and layout-scoped revision tokens
  plus authored source provenance on active notes (#45); affected-voice
  selectors targeting pattern node, section, layer, occurrence, or
  combined identities, with explicit preserve / release / immediate-stop
  policies and authored provenance on sourced snapshot queries (#46);
  `AffectedVoiceEditScope` and
  `PatternScheduler::apply_affected_voice_policy_for_edit` mapping
  pattern-node / occurrence / section / section-bounded layer edits to
  affected-voice targets (#47); unified
  `PatternScheduler::queue_playback_snapshot_edit` plus
  pattern/song-specific wrappers that stage replacement and apply the
  selected policy together (#48); active-voice live-control batches with
  preflighted all-or-nothing rejection on invalid controls and
  stale-handle rejection (#49); and live-control changes integrated into edit
  application so successful edits report both live-controlled voice count
  and scheduler-owned active-note removals (#50).
- **Scheduler edit orchestration documentation** (#51) — `scheduler/`
  ships a checked-markdown README example walking the public edit
  orchestration workflow from a sourced active pattern snapshot through
  replacement staging, affected-voice policy, optional live-control
  changes, and outcome counts. The example is run as part of package
  checks so future API drift fails the build.

### Changed

- Drum names cheatsheet trimmed to only the implemented sounds
  (`bd, sd, hh, cp, oh`); `cb`/`rim`/`tom` removed pending real
  synthesis design.
- DSP/browser demo helper APIs now label the remaining ambiguity-prone
  `Oscillator::process`, `DemoSource::tick_source`, `tick`, and
  `tick_source` parameters.
- Topology queue diagnostics now report
  `InvalidEdit(index, reason)` with stable `GraphTopologyEditError` reasons
  instead of only the failing batch index.
- `BoundVoicePool` now owns template validation and `ControlBindingMap`
  lifetime, so `PatternScheduler` no longer carries stale bindings.
- Graph control, hot-swap queue, topology queue, and runtime-control
  wrappers now provide `Result`-typed companion APIs
  (`GraphControlError`, `HotSwapQueueError`, `GraphTopologyQueueError`)
  on the mono and stereo paths so callers can observe errors instead of
  silently dropping invalid operations. The existing `Bool`-returning
  helpers remain for compatibility. Browser graph queue/control paths
  expose last-error string/code helpers while preserving the boolean
  wasm ABI.

### Fixed

- Feedback-recurrence Playwright flake — replaced fixed-sequence guard
  with polling for actual convergence band, removing CI runner timing
  dependence.

## [0.1.0] - 2026-04-22

First public release. MoonBit DSP audio engine covering Phases 0–5 of the
Salat Engine roadmap: AudioWorklet proof, DSP primitives, compiled graph
runtime, polyphonic voice pool, pattern engine, and a pattern-to-DSP
scheduler with mini-notation support.

### Added

- **DSP primitives** (`dsp/`) — sine/saw/square/triangle oscillators, white
  noise, ADSR envelopes, biquad filters (LPF/HPF/BPF), delay lines with
  feedback, gain, mix, hard clip, equal-power pan, and parameter smoothing.
  Primitive `process` methods and the compiled-graph per-sample render
  loop are zero-allocation; allocation paths (graph/voice instantiation,
  graph rebuild and topology/hot-swap setup, scheduler pattern query and
  control resolution, browser scheduler routing, debug validation,
  browser telemetry) live outside that loop.
- **Compiled graph runtime** (`graph/`) — declare signal graphs as `DspNode`
  arrays, compile to topologically sorted execution plans, process
  context-sized blocks (the browser AudioWorklet path uses 128-sample
  render quanta at 48 kHz). Hot-swap via equal-power crossfade, runtime
  topology editing (insert/delete/replace), control binding with
  orphan-binding detection, and mono-to-stereo routing.
- **Stereo graph path** — `CompiledStereoDsp` carries terminal-stereo
  graphs (`Mono → Pan → stereo post-processing → StereoOutput`), with
  `StereoGain`/`StereoClip`/`StereoBiquad`/`StereoDelay` post-processing
  nodes, `StereoMixDown` for fold-down, and parallel hot-swap and
  topology controllers (`CompiledStereoDspHotSwap`,
  `CompiledStereoDspTopologyController`).
- **Feedback graphs** — automatic `z^-1` back-edge insertion via a
  self-register model. Direct self-feedback, multiple simultaneous
  back-edges, and mixed-shape feedback (mono back-edges through `Pan`
  into terminal stereo) all compile to bounded recurrences.
- **Finally Tagless DSP algebra** — the same graph definition serves as a
  concrete AST for optimization and a trait-driven interpretation for
  extensibility.
- **Polyphonic voice pool** (`voice/`) — 32+ simultaneous voices with
  priority stealing (idle > oldest releasing > oldest active),
  generation-tagged handles, two-stage silence detection, per-voice
  equal-power pan.
- **Pattern engine** (`pattern/`) — standalone package built on rational
  time arcs with nine combinators (`silence`, `pure`, `fast`, `slow`,
  `rev`, `sequence`, `stack`, `every`, `filter_map`) producing events
  over `ControlMap`. Zero dependency on the DSP layers.
- **Mini-notation parser** (`mini/`) — text-to-pattern compiler
  (`s("bd sd hh sd").fast(2)`, `note("60 64 67")`), producing
  `Pat[ControlMap]`.
- **Pattern → DSP scheduler** (`scheduler/`) — drives `VoicePool` from a
  `Pat[ControlMap]`. Each event triggers `note_on` with control values
  resolved through a `ControlBindingMap`, and schedules the matching
  `note_off` from the event's end time.
- **Browser AudioWorklet integration** (`browser/`) — wasm-gc build with
  multi-pool drum routing and a Playwright-tested end-to-end path.
- **Facade re-export** — the top-level `dowdiness/moondsp` module
  re-exports the core DSP/graph/voice surface via `pub using` from `@dsp`,
  `@graph`, and `@voice`, so consumers write `@moondsp.X` for primitives,
  the compiled graph runtime, and the voice pool. The higher-level
  `pattern/`, `mini/`, `scheduler/`, and `browser/` packages are imported
  directly under their canonical paths.
- **Test suite** — 573 MoonBit tests across DSP, graph, voice, pattern,
  mini, and scheduler, plus a separate Playwright browser-integration
  suite (`npm run test:browser`).

### Notes

- This is the first tagged release. The library was previously developed
  under the name `mdsp`; all consumer-facing identifiers now use `moondsp`.
- **Labelled constructor arguments**: five constructors take labelled
  arguments at the call site to make intent explicit and surface ordering
  mistakes at compile time (ms vs. s on ADSR times, sample-rate vs.
  block-size on `DspContext`, cutoff vs. Q on biquad):
  `DspContext::new(sample_rate~, block_size~)`,
  `Adsr::new(attack_ms~, decay_ms~, sustain~, release_ms~)`,
  `DspNode::adsr(attack_ms~, decay_ms~, sustain~, release_ms~)`,
  `DspNode::biquad(input~, mode~, cutoff_hz~, q~)`,
  `Oscillator::process(..., freq_hz~)`. The corresponding trait methods
  (`DspSym::adsr`, `FilterSym::biquad`) remain positional for now.
- The `moondsp-browser-tools` npm workspace is `private: true` and exists
  only to host Playwright tests for the browser demo.

[Unreleased]: https://github.com/dowdiness/moondsp/compare/v0.6.0...HEAD
[0.6.0]: https://github.com/dowdiness/moondsp/compare/v0.5.1...v0.6.0
[0.5.1]: https://github.com/dowdiness/moondsp/releases/tag/v0.5.1
[0.5.0]: https://github.com/dowdiness/moondsp/releases/tag/v0.5.0
[0.4.0]: https://github.com/dowdiness/moondsp/releases/tag/v0.4.0
[0.3.1]: https://github.com/dowdiness/moondsp/releases/tag/v0.3.1
[0.3.0]: https://github.com/dowdiness/moondsp/releases/tag/v0.3.0
[0.2.0]: https://github.com/dowdiness/moondsp/releases/tag/v0.2.0
[0.1.0]: https://github.com/dowdiness/moondsp/releases/tag/v0.1.0
